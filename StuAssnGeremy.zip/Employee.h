
#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "Date.h"

#include <string>

const int EMP_IDX_LENGTH = 8;
const int EMP_NAME_LENGTH = 36;
const int EMP_EMAIL_LENGTH = 36;
const int EMP_IC_LENGTH = 11;
const int EMP_TEL_LENGTH = 16;
const int EMP_DATE_LENGTH = 16;
const std::string DATE_DELIMITER = "/";
const std::string RECORD_DELIMITER = ",";
const std::string CSV_FILE_HEADER_LINE = "Idx,Name,Email,IC,PhoneNum,HireDate,BirthDate";
using namespace std;
class Employee 
{
private:
    string empName;      // e.g., John Doe Anderson
    string empEmail;     // e.g., johndoe@virtualworld.com
    string empIC;        // e.g., S8765432G
    string empPhoneNum;  // e.g., (65) 87654321

    Date empHiredDate;
    Date empBirthDate;

public:
    Employee ();
    Employee(const string& name, const string& email,
             const string& ic, const string& phoneNum,
             const Date& hiredDate, const Date& birthDate);

    // Getters and setters
    const string& getName() const;
    void setName(const string& name);

    const string& getEmail() const;
    void setEmail(const string& email);

    const string& getIC() const;
    void setIC(const string& ic);

    const string& getPhoneNum() const;
    void setPhoneNum(const string& phoneNum);

    const Date& getHiredDate() const;
    void setHiredDate(const Date& date);

    const Date& getBirthDate() const;
    void setBirthDate(const Date& date);

};

#endif

