g++ 2400813Main.o Date.o MainMenuOptions.o 2400813Main.o -o test.run

