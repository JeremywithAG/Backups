#include "Date.h"
// Date validation
bool Date::isValidDate(int d, int m, int y) const
{
    if (y < 1900 || y > 2100) return false;
    if (m < 1 || m > 12) return false;
	
    int daysInMonth;
    switch (m)
    {
        case 4: case 6: case 9: case 11:
            daysInMonth = 30;
            break;
        case 2:
            daysInMonth = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)) ? 29 : 28;
            break;
        default:
            daysInMonth = 31;
    }

    return (d >= 1) && (d <= daysInMonth);
}
// Constructor
Date::Date(int d, int m, int y)
{
    if (isValidDate(d, m, y)) {
        day = d;
        month = m;
        year = y;
    } else {
        std::cout << "Invalid Date! date not updated! Using default date(01/01/2000)" << std::endl;
        day = 1;
        month = 1;
        year = 2000; // fallback to default
    }
}



// String representation
std::string Date::toString() const
{
    std::ostringstream oss;
    oss << std::setw(2) << std::setfill('0') << day << "/"
        << std::setw(2) << std::setfill('0') << month << "/"
        << year;

    return oss.str();
}

