#include "MainMenuOptions.h"


void printWelcomeMsg() {
    cout << "\n------------------------------------------------------" << endl;
    cout << "- Welcome to My Assn P2 Program! -" << endl;
    cout << "------------------------------------------------------" << endl;
    cout << "- Student Number : < 2400813 > " << endl;
    cout << "- Student Name : < Geremy Lee Yi Liang >" << endl;
    cout << endl;
}

int printMainMenuOptions() {
    cout << "\n-----------------------------------------------------" << endl;
    cout << "\n 1) Get current no. of records in Employee Database" << endl;
    cout << " 2) Read Data From File and Populate Employee DB" << endl;
    cout << " 3) Display All Records" << endl;
    cout << " 4) Search for records by IC" << endl;
    cout << " 5) Search for records by Name" << endl;
    cout << " 6) Search for records by Email" << endl;
    cout << " 7) Search for records by Phone Number" << endl;
    cout << " 8) INSERT New Employee Record" << endl;
    cout << " 9) Search (by ic) & UPDATE Existing Employee Record" << endl;
    cout << "10) Search (by ic) & DELETE Existing Employee Record" << endl;
    cout << "11) Write Data From Employee DB To File" << endl;
    cout << "12) Quit" << endl;
    cout << "\n-----------------------------------------------------" << endl;
    cout << endl;

    string UserInput;
    int choice;

    while (true) {
        cout << "Please enter your choice (1 - 12): ";
        getline(cin, UserInput);  // Read full input

        // Check if input consists only of digits
        bool isValid = !UserInput.empty();
        for (char c : UserInput) {
            if (!isdigit(c)) {
                isValid = false;
                break;
            }
        }

        // Convert to integer if valid
        if (isValid) {
            choice = stoi(UserInput);

            if (choice >= 1 && choice <= 12) {
                break;  // Valid input, exit loop
            }
        }

        cout << "Invalid input! Please enter a number between 1 and 12." << endl;
    }

    return (choice);
}

int queryCurrentNoOfEmpRecs () 
{
  return (empDBSize);

}

void readCSV(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open the file " << filename << "!" << endl;
        return;
    }

    string line, word;
    unordered_map<string, int> columnIndex;  // Column name -> position
    bool isHeader = true;

    while (getline(file, line)) {
    if (empDBSize >= MAX_NO_OF_RECORDS) {
        cerr << "Error: Database is full. Cannot store more records!" << endl;
        break; 
    }	
    	
        stringstream ss(line);
        string rowData[10];  // Array to hold split row data (Assuming max 10 columns)
        int colCount = 0;

        // Split CSV line into fields
        while (getline(ss, word, ',')) {
            rowData[colCount++] = word;
        }

        if (isHeader) {
            // Store column positions dynamically
            for (int i = 0; i < colCount; i++) {
                string colName = rowData[i];
                colName.erase(0, colName.find_first_not_of(" \t\r\n"));
				colName.erase(colName.find_last_not_of(" \t\r\n") + 1);
                for (char &c : colName) c = toupper(c); // Convert to uppercase
                columnIndex[colName] = i; // Store position
            }
            isHeader = false;
            continue;
        }

 		if (columnIndex.find("NAME") == columnIndex.end() ||
            columnIndex.find("EMAIL") == columnIndex.end() ||
            columnIndex.find("IC") == columnIndex.end() ||
            columnIndex.find("PHONENUM") == columnIndex.end() ||
            columnIndex.find("HIREDATE") == columnIndex.end() ||
            columnIndex.find("BIRTHDATE") == columnIndex.end()) {
            cerr << "Error: File header not in correct format!/ Missing column detected." << endl;
            continue;
        }
        // Retrieve column values dynamically
        string name = rowData[columnIndex["NAME"]];
        string email = rowData[columnIndex["EMAIL"]];
        string ic = rowData[columnIndex["IC"]];
        string phoneNum = rowData[columnIndex["PHONENUM"]];
        string hireDateStr = rowData[columnIndex["HIREDATE"]];
        string birthDateStr = rowData[columnIndex["BIRTHDATE"]];

        // Convert date format (Assuming DD/MM/YYYY)
        int hd, hm, hy, bd, bm, by;
        sscanf(hireDateStr.c_str(), "%d/%d/%d", &hd, &hm, &hy);
        sscanf(birthDateStr.c_str(), "%d/%d/%d", &bd, &bm, &by);
        Date hireDate(hd, hm, hy);
        Date birthDate(bd, bm, by);
        // Store Employee in array
        EmployeeRecordsDB[empDBSize] = Employee(name, email, ic, phoneNum, hireDate, birthDate);
        empDBSize++;
    }

    file.close();
    cout << "\nData successfully loaded from " << filename << ". Total records: " << empDBSize << endl;
}

void displayEmpRecs(){
if (empDBSize == 0) {
        cout << "No employee records found." << endl;
        return;
    }
     string UserInput;

    while (true) {
        cout << "Show Array Index? (y/n): ";
        getline(cin, UserInput);  // Read full input

        // Convert input to uppercase (if valid)
        if (UserInput.length() == 1) {
            UserInput[0] = toupper(UserInput[0]);
        }

        // Validate input
        if (UserInput == "Y" || UserInput == "N") {
            break;  // Valid input, exit loop
        }

        cout << "Invalid input! Please enter 'y' or 'n' only." << endl;
    	}

    if (UserInput == "Y") {
        int totalWidth = EMP_IDX_LENGTH + EMP_IC_LENGTH + EMP_NAME_LENGTH + EMP_TEL_LENGTH +
                         EMP_DATE_LENGTH + EMP_DATE_LENGTH + EMP_EMAIL_LENGTH;

        cout << setw(totalWidth) << setfill('=') << "=" << endl;
        cout << setfill(' '); // Reset fill character

        cout << left
             << setw(EMP_IDX_LENGTH) << "Idx"
             << setw(EMP_IC_LENGTH) << "IC"
             << setw(EMP_NAME_LENGTH) << "Name"
             << setw(EMP_TEL_LENGTH) << "Phone"
             << setw(EMP_DATE_LENGTH) << "BirthDate"
             << setw(EMP_DATE_LENGTH) << "HiredDate"
             << setw(EMP_EMAIL_LENGTH) << "Email"
             << endl;

        cout << setw(totalWidth) << setfill('=') << "=" << endl;
        cout << setfill(' ');

        for (int i = 0; i < empDBSize; i++) {
            cout << left << setw(EMP_IDX_LENGTH) << i;
            printEmpRecs(i);
        }
    } else {  // UserInput == 'N'
        int totalWidth = EMP_IC_LENGTH + EMP_NAME_LENGTH + EMP_TEL_LENGTH +
                         EMP_DATE_LENGTH + EMP_DATE_LENGTH + EMP_EMAIL_LENGTH;

        cout << setw(totalWidth) << setfill('=') << "=" << endl;
        cout << setfill(' '); // Reset fill character

        cout << left
             << setw(EMP_IC_LENGTH) << "IC"
             << setw(EMP_NAME_LENGTH) << "Name"
             << setw(EMP_TEL_LENGTH) << "Phone"
             << setw(EMP_DATE_LENGTH) << "BirthDate"
             << setw(EMP_DATE_LENGTH) << "HiredDate"
             << setw(EMP_EMAIL_LENGTH) << "Email"
             << endl;

        cout << setw(totalWidth) << setfill('=') << "=" << endl;
        cout << setfill(' ');

        for (int i = 0; i < empDBSize; i++) {
            printEmpRecs(i);
        }
    }
}

void searchICrecs(){
string searchIC = "00";
int choice;
do{

cout << "----------------------------------------------------------------"<<endl;
cout << "1) Enter an ic (current value = ' " << searchIC << " ' )"<<endl;
cout << "2) Search for employee IC = ' " << searchIC << " ' (i.e. EXACT MATCH)"<<endl;
cout << "3) Search for employee IC = ' " << searchIC << " ' (i.e. PARTIAL MATCH)"<<endl;
cout << "4) Back to Main Menu...."<<endl;
cout << "----------------------------------------------------------------"<<endl;

string UserInput;
    

    while (true) {
        cout << "Please enter your choice (1 - 4): ";
        getline(cin, UserInput);  // Read full input
		cout << endl;
        // Check if input consists only of digits
        bool isValid = !UserInput.empty();
        for (char c : UserInput) {
            if (!isdigit(c)) {
                isValid = false;
                break;
            }
        }

        // Convert to integer if valid
        if (isValid) {
            choice = stoi(UserInput);

            if (choice >= 1 && choice <= 4) {
                break;  // Valid input, exit loop
            }
        }
        cout << "Invalid input! Please enter a number between 1 and 4." << endl;
        }

	switch(choice){
		case 1:{
		string tempIC;
		cout << "Please type in ic value to search for (< 10 chars) : ";
		getline(cin, tempIC); // Allow spaces in input
		cout<<endl;
                if (tempIC.length() < 10) {
                    searchIC = tempIC;
                } else {
                    cout << "Error: IC must be less than 10 characters. Try again." << endl;
                }
		break;
		}
		case 2:{
		cout << "Records with IC EXACTLY matching '" << searchIC << "':" << endl;
    
    bool found = false;

    for (int i = 0; i < empDBSize; i++) {
        if (EmployeeRecordsDB[i].getIC() == searchIC) {
            printEmpRecs(i);
            found = true;
        }
    }

    if (!found) {
        cout << "No matching records FOUND!!!" << endl;
    }
    break;
    }
		case 3:{
		cout << "Records with IC PARTIALLY matching ' " << searchIC << " ' :"<<endl;
		
			bool found = false;
		
		for (int i = 0; i < empDBSize; i++) {
			if (EmployeeRecordsDB[i].getIC().find(searchIC) !=string::npos) {
				if (!found) { // Print header only once when first match is found
              	  printheader();
              	  
              	  found = true;
		          
            		}
            		printEmpRecs(i);
			}
		}
	
		if (!found) {
			cout << "No matching records FOUND RAGHHHH!!!" << endl;
		}
		break;
		}
		case 4:
		
		break;
		}
}while(choice!=4);

}

void searchNameRecs(){
string searchName = "SAMPLE NAME";
int choice;
do{

cout << "----------------------------------------------------------------"<<endl;
cout << "1) Enter a name (current value = ' " << searchName << " ' )"<<endl;
cout << "2) Search for employee name = ' " << searchName << " ' (i.e. EXACT MATCH)"<<endl;
cout << "3) Search for employee name containing = ' " << searchName << " ' (i.e. PARTIAL MATCH)"<<endl;
cout << "4) Back to Main Menu...."<<endl;
cout << "----------------------------------------------------------------"<<endl;

string UserInput;
    

    while (true) {
        cout << "Please enter your choice (1 - 4): ";
        getline(cin, UserInput);  // Read full input
		cout << endl;
        // Check if input consists only of digits
        bool isValid = !UserInput.empty();
        for (char c : UserInput) {
            if (!isdigit(c)) {
                isValid = false;
                break;
            }
        }

        // Convert to integer if valid
        if (isValid) {
            choice = stoi(UserInput);

            if (choice >= 1 && choice <= 4) {
                break;  // Valid input, exit loop
            }
        }
        cout << "Invalid input! Please enter a number between 1 and 4." << endl;
        }

switch(choice){
		case 1:{
		string tempName;
		cout << "Please type in name value to search for (< 35 chars) : ";
		getline(cin, tempName); // Allow spaces in input
		
                if (tempName.length() < 35) {
                    searchName = tempName;
                } else {
                    cout << "Error: name must be less than 35 characters. Try again." << endl;
                }
		break;
		}
		case 2:{
		cout << "Records with name EXACTLY matching '" << searchName << "':" << endl;
    string upperSearchName = searchName;
	transform(upperSearchName.begin(), upperSearchName.end(), upperSearchName.begin(), ::toupper);// Make SearchName toupper

	bool found = false;

	for (int i = 0; i < empDBSize; i++) {
		string empName = EmployeeRecordsDB[i].getName();
		transform(empName.begin(), empName.end(), empName.begin(), ::toupper);

		if (empName == upperSearchName) {
			printheader();
		    printEmpRecs(i);
		    found = true;
		}
	}

if (!found) {
    cout << "No matching records FOUND!!!" << endl;
}
    break;
    }
		case 3:{
		cout << "Records with name PARTIALLY matching ' " << searchName << " ' :" << endl;

		bool found = false;

		// Convert searchName to uppercase for case-insensitive search
		string upperSearchName = searchName;
		transform(upperSearchName.begin(), upperSearchName.end(), upperSearchName.begin(), ::toupper);

		for (int i = 0; i < empDBSize; i++) {
			// Convert employee name to uppercase for comparison
			string empName = EmployeeRecordsDB[i].getName();
			transform(empName.begin(), empName.end(), empName.begin(), ::toupper);

			if (empName.find(upperSearchName) != string::npos) {
				if (!found) { 
				    printheader();  // Print header only once when first match is found
				    found = true;
				}
				printEmpRecs(i);
			}
		}

		if (!found) {
			cout << "No matching records FOUND RAGHHHH!!!" << endl;
		}
		break;
		}
		case 4:
		
		break;
		}
}while(choice!=4);
}

void searchEmailRecs(){
int choice;
string searchEmail = "SAMPLE EMAIL";

do{

cout << "----------------------------------------------------------------"<<endl;
cout << "1) Enter a email (current value = ' " << searchEmail << " ' )"<<endl;
cout << "2) Search for employee's email = ' " << searchEmail << " ' (i.e. EXACT MATCH)"<<endl;
cout << "3) Search for employee email containing = ' " << searchEmail << " ' (i.e. PARTIAL MATCH)"<<endl;
cout << "4) Back to Main Menu...."<<endl;
cout << "----------------------------------------------------------------"<<endl;
string UserInput;
    

    while (true) {
        cout << "Please enter your choice (1 - 4): ";
        getline(cin, UserInput);  // Read full input
		cout << endl;
        // Check if input consists only of digits
        bool isValid = !UserInput.empty();
        for (char c : UserInput) {
            if (!isdigit(c)) {
                isValid = false;
                break;
            }
        }

        // Convert to integer if valid
        if (isValid) {
            choice = stoi(UserInput);

            if (choice >= 1 && choice <= 4) {
                break;  // Valid input, exit loop
            }
        }
        cout << "Invalid input! Please enter a number between 1 and 4." << endl;
        }

switch(choice){
		case 1:{
		string tempEmail;
		cout << "Please type in email value to search for (< 35 chars) : ";
		getline(cin, tempEmail); // Allow spaces in input
		
                if (tempEmail.length() < 35) {
                    searchEmail = tempEmail;
                } else {
                    cout << "Error: Email must be less than 35 characters. Try again." << endl;
                }
		break;
		}
		case 2:{
		cout << "Records with Email EXACTLY matching '" << searchEmail << "':" << endl;
    
    bool found = false;

    for (int i = 0; i < empDBSize; i++) {
        if (EmployeeRecordsDB[i].getEmail() == searchEmail) {
            printEmpRecs(i);
            found = true;
        }
    }

    if (!found) {
        cout << "No matching records FOUND!!!" << endl;
    }
    break;
    }
		case 3:{
		cout << "Records with Email PARTIALLY matching ' " << searchEmail << " ' :"<<endl;
		
			bool found = false;
		
		for (int i = 0; i < empDBSize; i++) {
			if (EmployeeRecordsDB[i].getEmail().find(searchEmail) !=string::npos) {
				if (!found) { // Print header only once when first match is found
              	  printheader();
              	  
              	  found = true;
		          
            		}
            		printEmpRecs(i);
			}
		}
	
		if (!found) {
			cout << "No matching records FOUND RAGHHHH!!!" << endl;
		}
		break;
		}
		case 4:
		
		break;
		}
}while(choice!=4);
}

void searchPhoneRecs(){
int choice;
string searchPhoneNum = "SAMPLE PHONENUM";

do{

cout << "----------------------------------------------------------------"<<endl;
cout << "1) Enter a Phone Number (current value = ' " << searchPhoneNum << " ' )"<<endl;
cout << "2) Search for employee's Phone Number = ' " << searchPhoneNum << " ' (i.e. EXACT MATCH)"<<endl;
cout << "3) Search for employee Phone Number containing = ' " << searchPhoneNum << " ' (i.e. PARTIAL MATCH)"<<endl;
cout << "4) Back to Main Menu...."<<endl;
cout << "----------------------------------------------------------------"<<endl;
string UserInput;
    

    while (true) {
        cout << "Please enter your choice (1 - 4): ";
        getline(cin, UserInput);  // Read full input
		cout << endl;
        // Check if input consists only of digits
        bool isValid = !UserInput.empty();
        for (char c : UserInput) {
            if (!isdigit(c)) {
                isValid = false;
                break;
            }
        }

        // Convert to integer if valid
        if (isValid) {
            choice = stoi(UserInput);

            if (choice >= 1 && choice <= 4) {
                break;  // Valid input, exit loop
            }
        }
        cout << "Invalid input! Please enter a number between 1 and 4." << endl;
        }

switch(choice){
		case 1:{
		string tempPhoneNum;
		cout << "Please type in Phone Number value to search for (< 35 chars) : ";
		getline(cin, tempPhoneNum); // Allow spaces in input
		
                if (tempPhoneNum.length() < 35) {
                    searchPhoneNum = tempPhoneNum;
                } else {
                    cout << "Error: Phone Number must be less than 35 characters. Try again." << endl;
                }
		break;
		}
		case 2:{
		cout << "Records with Phone Number EXACTLY matching '" << searchPhoneNum << "':" << endl;
    
    bool found = false;

    for (int i = 0; i < empDBSize; i++) {
        if (EmployeeRecordsDB[i].getPhoneNum() == searchPhoneNum) {
            printEmpRecs(i);
            found = true;
        }
    }

    if (!found) {
        cout << "No matching records FOUND!!!" << endl;
    }
    break;
    }
		case 3:{
		cout << "Records with Phone Number PARTIALLY matching ' " << searchPhoneNum << " ' :"<<endl;
		
			bool found = false;
		
		for (int i = 0; i < empDBSize; i++) {
			if (EmployeeRecordsDB[i].getPhoneNum().find(searchPhoneNum) !=string::npos) {
				if (!found) { // Print header only once when first match is found
              	  printheader();
              	  
              	  found = true;
		          
            		}
            		printEmpRecs(i);
			}
		}
	
		if (!found) {
			cout << "No matching records FOUND RAGHHHH!!!" << endl;
		}
		break;
		}
		case 4:
		
		break;
		}
}while(choice!=4);
}

void insertNewEmpRec() {
	int hd, hm, hy, bd, bm, by;
    string userName, userIC, userEmail, userPhoneNum, birthDateStr, hiredDateStr;
    Date userBirthDate, userHiredDate;

    if (empDBSize >= MAX_NO_OF_RECORDS) {  
        cout << "Error: Database is full!\n";
        return;
    }

    // Get Employee Name
    cout << "Please type in employee's name (<35 chars): ";
    
    getUserInput(userName, 35);
    checkDupe(1, userName);

    // Get Employee IC
    cout << "Please type in employee's IC (<10 chars): ";
    getUserInput(userIC, 10);
    checkDupe(2, userIC);

    // Get Employee Email
    cout << "Please type in employee's Email (<35 chars): ";
    getUserInput(userEmail, 35);
    checkDupe(3, userEmail);

    // Get Employee Phone Number
    cout << "Please type in employee's Phone Number (<15 chars): ";
    getUserInput(userPhoneNum, 15);
    checkDupe(4, userPhoneNum);

    // Get Employee DOB
    cout << "Please type in employee's date of birth (dd/mm/yyyy): ";
    getUserInput(birthDateStr, 15);
    checkDupe(5, birthDateStr);
    sscanf(birthDateStr.c_str(), "%d/%d/%d", &bd, &bm, &by); 
	Date birthDate(bd, bm, by);
	
    // Get Employee Hired Date
    cout << "Please type in employee's hire date (dd/mm/yyyy): ";
    getUserInput(hiredDateStr, 15);
    checkDupe(6, hiredDateStr);
    sscanf(hiredDateStr.c_str(), "%d/%d/%d", &hd, &hm, &hy);
    Date hireDate(hd, hm, hy);
          
    // Insert new employee record only after all checks
    EmployeeRecordsDB[empDBSize].setName(userName);
    EmployeeRecordsDB[empDBSize].setIC(userIC);
    EmployeeRecordsDB[empDBSize].setEmail(userEmail);
    EmployeeRecordsDB[empDBSize].setPhoneNum(userPhoneNum);
    EmployeeRecordsDB[empDBSize].setBirthDate(birthDate);
    EmployeeRecordsDB[empDBSize].setHiredDate(hireDate);
    empDBSize++;  // Increase size after storing all details

    cout << "Employee '" << EmployeeRecordsDB[empDBSize - 1].getName() 
         << "' with IC '" << EmployeeRecordsDB[empDBSize - 1].getIC() 
         << "' added successfully!\n";
}

void printheader() {
    int totalWidth = EMP_IC_LENGTH + EMP_NAME_LENGTH + EMP_TEL_LENGTH + 
                     EMP_DATE_LENGTH + EMP_DATE_LENGTH + EMP_EMAIL_LENGTH;

    cout << setw(totalWidth) << setfill('=') << "=" << endl;
    cout << setfill(' '); // Reset fill character

    cout << left
         << setw(EMP_IC_LENGTH) << "IC"
         << setw(EMP_NAME_LENGTH) << "Name"
         << setw(EMP_TEL_LENGTH) << "Phone"
         << setw(EMP_DATE_LENGTH) << "BirthDate"
         << setw(EMP_DATE_LENGTH) << "HiredDate"
         << setw(EMP_EMAIL_LENGTH) << "Email"  
         << endl;

    cout << setw(totalWidth) << setfill('=') << "=" << endl;
    cout << setfill(' '); // Reset fill character again
}
void printEmpRecs(int i){
//Print Employee Records with no Index
		    cout << left << setw(11) << EmployeeRecordsDB[i].getIC()
		         << left << setw(36) << EmployeeRecordsDB[i].getName()
		         << left << setw(16) << EmployeeRecordsDB[i].getPhoneNum()
		         << left << setw(16) << EmployeeRecordsDB[i].getBirthDate().toString()
		         << left << setw(16) << EmployeeRecordsDB[i].getHiredDate().toString()
		         << left << setw(36) << EmployeeRecordsDB[i].getEmail()
		         << endl;
}
void getUserInput(string& input, int maxLength) {
    getline(cin, input);

    // Check if input exceeds max length
    if (input.length() > maxLength) {
        cout << "Error: Input exceeds " << maxLength << " characters. Please try again.\n";
        getUserInput(input, maxLength);  // Recursively ask for input again
    }
}
bool checkDupe(int fieldType, string& checkVal) {
    string userInput;

    while (true) {
        bool isDuplicate = false;

        for (int i = 0; i < empDBSize; i++) {
            string existingValue;

            switch (fieldType) {
                case 1: existingValue = EmployeeRecordsDB[i].getName(); break;
                case 2: existingValue = EmployeeRecordsDB[i].getIC(); break;
                case 3: existingValue = EmployeeRecordsDB[i].getEmail(); break;
                case 4: existingValue = EmployeeRecordsDB[i].getPhoneNum(); break;
                case 5: existingValue = EmployeeRecordsDB[i].getBirthDate().toString(); break;
                case 6: existingValue = EmployeeRecordsDB[i].getHiredDate().toString(); break;
                default:
                    cout << "Error: Invalid field type!\n";
                    return false;
            }

            if (existingValue == checkVal) {
                cout << "Error! '" << checkVal << "' already exists in the employee DB.\n";
                cout << "Do you INSIST this is correct? (y/n): ";
                cin >> userInput;

                if (userInput.length() == 1) {
                    char inputChar = toupper(userInput[0]);

                    if (inputChar == 'Y') {
                        cout << "Proceeding with duplicate entry '" << checkVal << "'...\n";
                        return true;  // Allow duplicate
                    } else if (inputChar == 'N') {
                        cout << "Please enter a new value: ";
                        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear buffer
                        getline(cin, checkVal);  // New input
                        isDuplicate = true;  // Flag to restart check
                        break;  // Break from for loop to recheck new value
                    }
                }
                cout << "Invalid input. Please enter Y or N.\n";
                isDuplicate = true;
                break;
            }
        }

        if (!isDuplicate) return false;  // No duplicates, proceed
        // else continue looping to check updated `checkVal`
    }
}


void UpdateRec() {
    string searchIC;
    
    // Prompt user for IC input and ensure it meets the constraints
    while (true) {
        cout << "Please type in existing employee's IC (<10 chars, no spaces): ";
        cin >> searchIC;
        cin.ignore();

        // Remove all spaces
        searchIC.erase(remove(searchIC.begin(), searchIC.end(), ' '), searchIC.end());

        // Convert to uppercase
        transform(searchIC.begin(), searchIC.end(), searchIC.begin(), ::toupper);

        // Validate length
        if (searchIC.length() < 10) {
            break;
        } else {
            cout << "Error: IC must be less than 10 characters. Please try again." << endl;
        }
    }

    bool found = false;
    int index = -1;

    // Search for the employee record
    for (int i = 0; i < empDBSize; i++) {
        if (EmployeeRecordsDB[i].getIC() == searchIC) {
            found = true;
            index = i;
            cout << "Records with IC EXACTLY matching '" << searchIC << "':" << endl;
            printheader();
            printEmpRecs(i);
            break;
        }
    }

    // If no matching records were found
    if (!found) {
        cout << "No matching records found for IC: " << searchIC << endl;
        return;
    }

    int choice;
    do {
        // Display update menu
        cout << "\n++++++++++++++++++++++++++++\n";
        cout << "+++ Item to be updated ... +++\n";
        cout << "++++++++++++++++++++++++++++++\n";
        cout << "1) Update IC          (curr. value = '" << EmployeeRecordsDB[index].getIC() << "')\n";
        cout << "2) Update Email       (curr. value = '" << EmployeeRecordsDB[index].getEmail() << "')\n";
        cout << "3) Update Name        (curr. value = '" << EmployeeRecordsDB[index].getName() << "')\n";
        cout << "4) Update Phone Number (curr. value = '" << EmployeeRecordsDB[index].getPhoneNum() << "')\n";
        cout << "5) Update Birth Date  (curr. value = '" << EmployeeRecordsDB[index].getBirthDate().toString() << "')\n";
        cout << "6) Update Hired Date  (curr. value = '" << EmployeeRecordsDB[index].getHiredDate().toString() << "')\n";
        cout << "7) Done with updates\n";
        cout << "++++++++++++++++++++++++++++++++++++++\n";
        cout << "Please enter your choice (1 - 7): ";
        cin >> choice;
        cin.ignore();

        string newValue;
        int d, m, y;

        switch (choice) {
            case 1:  // Update IC
                while (true) {
                    cout << "Enter new IC (<10 chars, no spaces): ";
                    cin >> newValue;
                    cin.ignore();
                    newValue.erase(remove(newValue.begin(), newValue.end(), ' '), newValue.end());
                    transform(newValue.begin(), newValue.end(), newValue.begin(), ::toupper);

                    if (newValue.length() < 10) {
                        EmployeeRecordsDB[index].setIC(newValue);
                        cout << "IC updated successfully!\n";
                        break;
                    } else {
                        cout << "Error: IC must be less than 10 characters.\n";
                    }
                }
                break;

            case 2:  // Update Email
                cout << "Enter new Email: ";
                getline(cin, newValue);
                EmployeeRecordsDB[index].setEmail(newValue);
                cout << "Email updated successfully!\n";
                break;

            case 3:  // Update Name
                cout << "Enter new Name: ";
                getline(cin, newValue);
                EmployeeRecordsDB[index].setName(newValue);
                cout << "Name updated successfully!\n";
                break;

            case 4:  // Update Phone Number
                cout << "Enter new Phone Number: ";
                getline(cin, newValue);
                EmployeeRecordsDB[index].setPhoneNum(newValue);
                cout << "Phone Number updated successfully!\n";
                break;

            case 5:  // Update Birth Date
                cout << "Enter new Birth Date (dd/mm/yyyy): ";
                getline(cin, newValue);
                sscanf(newValue.c_str(), "%d/%d/%d", &d, &m, &y);
                EmployeeRecordsDB[index].setBirthDate(Date(d, m, y));
                cout << "Birth Date updated successfully!\n";
                break;

            case 6:  // Update Hired Date
                cout << "Enter new Hired Date (dd/mm/yyyy): ";
                getline(cin, newValue);
                sscanf(newValue.c_str(), "%d/%d/%d", &d, &m, &y);
                EmployeeRecordsDB[index].setHiredDate(Date(d, m, y));
                cout << "Hired Date updated successfully!\n";
                break;

            case 7:
                cout << "Exiting update menu.\n";
                break;

            default:
                cout << "Invalid choice. Please enter a number between 1 and 7.\n";
        }
    } while (choice != 7);
}
void DeleteRec(){
string searchIC;
    
    // Prompt user for IC input and ensure it meets the constraints
    while (true) {
        cout << "Please type in existing employee's IC (<10 chars, no spaces): ";
        cin >> searchIC;
        cin.ignore();

        // Remove all spaces
        searchIC.erase(remove(searchIC.begin(), searchIC.end(), ' '), searchIC.end());

        // Convert to uppercase
        transform(searchIC.begin(), searchIC.end(), searchIC.begin(), ::toupper);

        // Validate length
        if (searchIC.length() < 10) {
            break;
        } else {
            cout << "Error: IC must be less than 10 characters. Please try again." << endl;
        }
    }

    bool found = false;
    int index = -1;

    // Search for the employee record
    for (int i = 0; i < empDBSize; i++) {
        if (EmployeeRecordsDB[i].getIC() == searchIC) {
            found = true;
            index = i;
            cout << "Records with IC EXACTLY matching '" << searchIC << "':" << endl;
            printheader();
            printEmpRecs(i);
            break;
        }
    }

    // If no matching records were found
    if (!found) {
        cout << "No matching records found for IC: " << searchIC << endl;
        return;
    }
    
    char choice;
    cout << "Confirm Deletion of record? (y/n): ";
    cin >> choice;
    choice = toupper(choice);

    if (choice == 'Y') {
        // Shift records left to remove the deleted entry
        for (int i = index; i < empDBSize - 1; i++) {
            EmployeeRecordsDB[i] = EmployeeRecordsDB[i + 1];
        }

        // Reduce the database size
        empDBSize--;

        cout << "Employee record with IC '" << searchIC << "' has been deleted successfully.\n";
    } else {
        cout << "Deletion canceled.\n";
    }
}
    


void ExportToCSV() {
    string filename;

    // Prompt user for a filename
    cout << "Enter the filename to export the employee database (e.g., employees.csv): ";
    cin >> filename;

    // Ensure filename ends with ".csv"
    if (filename.find(".csv") == string::npos) {
        filename += ".csv";
    }

    ofstream file(filename);

    // Check if file is open
    if (!file.is_open()) {
        cout << "Error: Could not open file '" << filename << "' for writing!\n";
        return;
    }

    // Write CSV header
    file << "IC,Name,Email,Phone Number,Birth Date,Hired Date\n";

    // Write employee records to file
    for (int i = 0; i < empDBSize; i++) {
        file << EmployeeRecordsDB[i].getIC() << ","
             << EmployeeRecordsDB[i].getName() << ","
             << EmployeeRecordsDB[i].getEmail() << ","
             << EmployeeRecordsDB[i].getPhoneNum() << ","
             << EmployeeRecordsDB[i].getBirthDate().toString() << ","
             << EmployeeRecordsDB[i].getHiredDate().toString() << "\n";
    }

    file.close();
    cout << "Employee database successfully exported to '" << filename << "'!\n";
}
