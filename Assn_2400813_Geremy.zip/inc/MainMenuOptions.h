#ifndef MAINMENUOPTIONS_H
#define MAINMENUOPTIONS_H

#include "Employee.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <limits>
#include <algorithm>
#include <unordered_map>

#define MAX_NO_OF_RECORDS 300  // Define the maximum records here

// Global variables (Declared as extern so they are defined in MainMenu.cpp)
extern Employee EmployeeRecordsDB[MAX_NO_OF_RECORDS];
extern int empDBSize;

using namespace std;

// Function prototypes
void printWelcomeMsg();
int printMainMenuOptions();
int queryCurrentNoOfEmpRecs();
void readCSV(const std::string& filename);
void displayEmpRecs();
void searchICrecs();
void searchNameRecs();
void searchEmailRecs();
void searchPhoneRecs();
void insertNewEmpRec();
void getUserInput(string& input, int maxLength);
bool checkDupe(int fieldType, string& checkVal);
void UpdateRec();
void DeleteRec();
void ExportToCSV();
void printheader();
void printEmpRecs(int i);

#endif  // MAINMENUOPTIONS_H

