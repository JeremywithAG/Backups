#include <iostream>
#include <fstream>
#include <string>

#include "Functions.h"

using namespace std;

static ofstream logFile;
static streambuf* originalCoutBuffer = nullptr;
static DualStreamBuf* dualBuffer = nullptr;

DualStreamBuf::DualStreamBuf(streambuf* original, ofstream& logFile)
    : originalBuffer(original), file(logFile) {}

int DualStreamBuf::overflow(int c) 
{
    if (c == EOF)
        return !EOF;
    // Write character to the original console.
    if (originalBuffer->sputc(c) == EOF)
        return EOF;
    // Also write to the log file.
    if (file.put(c).fail())
        return EOF;
    return c;
}

streamsize DualStreamBuf::xsputn(const char* s, streamsize n) 
{
    streamsize count = originalBuffer->sputn(s, n);
    file.write(s, n);
    return count;
}

void initializeLogging(const string &outputFilename) 
{
    logFile.open(outputFilename);
    if (!logFile.is_open()) {
        cerr << "Error: could not open log file " << outputFilename << endl;
        return;
    }
    originalCoutBuffer = cout.rdbuf();
    dualBuffer = new DualStreamBuf(originalCoutBuffer, logFile);
    cout.rdbuf(dualBuffer);
}

string getLoggedInput(const string &prompt)
 {
    string input;
    cout << prompt;
    getline(cin, input);
    logFile << "\n[User Input]: " << input << "\n";
    return input;
}

void restoreLogging()
 {
    if (originalCoutBuffer != nullptr) {
        cout.rdbuf(originalCoutBuffer);
    }
    if (dualBuffer) {
        delete dualBuffer;
        dualBuffer = nullptr;
    }
    if (logFile.is_open()) {
        logFile.close();
    }
}
