#include "Functions.h"
#include "GridArea.h"
#include "Vehicle.h"

#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <cctype>     // for isspace
#include <algorithm>  // for std::remove

using namespace std;

vector<vector<char>> parseMapFromFile(const string& filename)
{
    ifstream infile(filename);
    vector<vector<char>> mapData;

    if (!infile.is_open())
    {
        cerr << "Error opening file: " << filename << endl;
        return mapData;
    }

    string line;
    while (getline(infile, line))
    {
        // Remove any '\r' characters 
        line.erase(remove(line.begin(), line.end(), '\r'), line.end());

        // Strip trailing whitespace
        while (!line.empty() && isspace(static_cast<unsigned char>(line.back())))
        {
            line.pop_back();
        }

        // Convert '.' to an actual space if the file uses '.' as "blank"
        for (char &c : line)
        {
            if (c == '.')
                c = ' ';
        }

        // Store entire line as a row of chars
        vector<char> row(line.begin(), line.end());
        mapData.push_back(row);
    }

    infile.close();

    // Determine maximum width among all rows
    size_t maxWidth = 0;
    for (auto &r : mapData)
    {
        if (r.size() > maxWidth)
            maxWidth = r.size();
    }

    // Pad any shorter rows with spaces so every row matches maxWidth
    for (auto &r : mapData)
    {
        while (r.size() < maxWidth)
        {
            r.push_back(' ');
        }
    }

    return mapData;
}

vector<vector<GridArea>> convertCharMapToGridArea(const vector<vector<char>>& charMap)
{
    vector<vector<GridArea>> grid;
    for (int y = 0; y < (int)charMap.size(); ++y)
    {
        vector<GridArea> row;
        for (int x = 0; x < (int)charMap[y].size(); ++x)
        {
            char c = charMap[y][x];
            TERRAIN_TYPE t = GridArea::convertCharToTerrainType(c);
            GridArea g(x, y, t);
            row.push_back(g);
        }
        grid.push_back(row);
    }
    return grid;
}
