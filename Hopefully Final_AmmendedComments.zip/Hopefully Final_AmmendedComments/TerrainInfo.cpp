#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include "Functions.h"

// Array of required terrain symbols, initialized to "N.A."
TerrainInfo terrainInfo[] =
 {
    { ' ', false, "N.A.", "N.A." },
    { 'w', false, "N.A.", "N.A." },
    { 'f', false, "N.A.", "N.A." },
    { 'j', false, "N.A.", "N.A." },
    { 'h', false, "N.A.", "N.A." },
    { 'M', false, "N.A.", "N.A." },
    { '~', false, "N.A.", "N.A." },
    { 'X', false, "N.A.", "N.A." },
    { '#', false, "N.A.", "N.A." },
    { 'S', false, "N.A.", "N.A." },
    { 'E', false, "N.A.", "N.A." }
};

// Resets all terrain entries to undiscovered and "N.A."
void initTerrainInfo()
{
    int size = sizeof(terrainInfo) / sizeof(terrainInfo[0]);
    for (int i = 0; i < size; i++) {
        terrainInfo[i].discovered   = false;
        terrainInfo[i].movtEnergy   = "N.A.";
        terrainInfo[i].shieldEnergy = "N.A.";
    }
}

// Updates terrain movement/shield energy only once per symbol
void updateTerrainEnergyReq(char terrainSymbol, long movtUsed, long shieldUsed)
{
    int size = sizeof(terrainInfo) / sizeof(terrainInfo[0]);
    for (int i = 0; i < size; i++) {
        if (terrainInfo[i].symbol == terrainSymbol) {
            if (!terrainInfo[i].discovered) {
                terrainInfo[i].discovered   = true;
                terrainInfo[i].movtEnergy   = std::to_string(movtUsed);
                terrainInfo[i].shieldEnergy = std::to_string(shieldUsed);
            }
            break;
        }
    }
}

// Prints a formatted table of terrain symbols and their energy requirements
void printTerrainInfo()
{
    std::cout << "\nTerrain Symbol   Movt Enrg Reqd   Shld Enrg Reqd\n";
    std::cout << "--------------   --------------   --------------\n";
    int size = sizeof(terrainInfo) / sizeof(terrainInfo[0]);
    for (int i = 0; i < size; i++) {
        if (terrainInfo[i].symbol == 'S' || terrainInfo[i].symbol == 'E' || terrainInfo[i].symbol == '#')
            continue;
        std::cout << std::setw(14)
                  << ("'" + std::string(1, terrainInfo[i].symbol) + "'")
                  << std::setw(17) << terrainInfo[i].movtEnergy
                  << std::setw(16) << terrainInfo[i].shieldEnergy
                  << "\n";
    }
    std::cout << std::endl;
}

long getMovementCostForSymbol(char terrainSymbol)
{
    int size = sizeof(terrainInfo) / sizeof(terrainInfo[0]);
    for (int i = 0; i < size; i++)
    {
        if (terrainInfo[i].symbol == terrainSymbol)
        {
            // If discovered, parse movtEnergy
            if (terrainInfo[i].movtEnergy != "N.A.")
            {
                return stol(terrainInfo[i].movtEnergy);
            }
            else
            {
                // not discovered => fallback
                return 999;
            }
        }
    }
    // not found => fallback
    return 999;
}
