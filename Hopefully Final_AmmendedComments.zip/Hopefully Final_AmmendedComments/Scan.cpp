#include <iostream>

#include "SatComRelay.h"
#include "Functions.h"
#include "VehData.h"
#include "GridArea.h"

using namespace std;

extern SatComRelay relay;
extern VehData vehicleData;

extern int vehiclex;
extern int vehicley;

extern std::vector<std::vector<char>> maparr;

void scanall() 
{
    char scanresult;

    scanresult = relay.scanSouthWest(vehicleData);
    maparr[vehicley + 1][vehiclex - 1] = scanresult;
    
    scanresult = relay.scanSouth(vehicleData);
    maparr[vehicley + 1][vehiclex] = scanresult;
    
    scanresult = relay.scanSouthEast(vehicleData);
    maparr[vehicley + 1][vehiclex + 1] = scanresult;
    
    scanresult = relay.scanWest(vehicleData);
    maparr[vehicley][vehiclex - 1] = scanresult;
    
    scanresult = relay.scanEast(vehicleData);
    maparr[vehicley][vehiclex + 1] = scanresult;
    
    scanresult = relay.scanNorthWest(vehicleData);
    maparr[vehicley - 1][vehiclex - 1] = scanresult;
    
    scanresult = relay.scanNorth(vehicleData);
    maparr[vehicley - 1][vehiclex] = scanresult;
    
    scanresult = relay.scanNorthEast(vehicleData);
    maparr[vehicley - 1][vehiclex + 1] = scanresult;
}
