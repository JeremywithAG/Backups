#include <iostream>
#include <string>
#include <limits>

#include "SatComRelay.h"
#include "Functions.h"
#include "GridArea.h"
#include "VehData.h"

using namespace std;


void displayMainMenu(int teamNumber, const string& teamLeaderName, int depth)
{
	string indent(depth, '\t'); 
    cout << endl << indent << "\033[1mTeam Number\033[0m        : " << teamNumber << endl;
    cout << indent << "\033[1mTeam Leader Name\033[0m   : " << teamLeaderName << endl;
    cout << indent << "------------------------------------------" << endl << endl;
    cout << indent << "Welcome to Team " << teamNumber << " Group Project" << endl << endl;
    cout << indent << "1) Configure Autopilot Mapping Exploration settings" << endl;
    cout << indent << "2) Configure Terrain Exploration Simulator settings" << endl;
    cout << indent << "3) Start Autopilot Mapping!" << endl;
    cout << indent << "4) Start Simulation!" << endl;
    cout << indent << "5) End" << endl << endl;
}

void configureSimulatorSettings(string& inputMapFilename, string& outputRouteFilename, string& routeCriteria, string& vehicleType, int depth)
{
    char choice;
    string indent(depth, '\t');
    do {
        cout << endl << indent << "	[ Configure Terrain Exploration Simulator settings ]\n" << endl;
        cout << indent << "	a) Specify INPUT map details filename (current: \033[32m" << inputMapFilename << "\033[0m)" << endl;
        cout << indent << "	b) Specify OUTPUT route report filename (current: \033[32m" << outputRouteFilename << "\033[0m)" << endl;
        cout << indent << "	c) Specify ideal route criteria (current: \033[32m" << routeCriteria << "\033[0m)" << endl;
        cout << indent << "	d) Specify vehicle type (current: \033[32m" << vehicleType << "\033[0m)" << endl;
        cout << indent << "	e) Back to main menu" << endl << endl;

        choice = getValidatedCharChoice("abcde",depth + 1);


        switch (choice)
        {
        case 'a':
        {
            string prompt = "Please enter INPUT map details filename (current: \033[32m" + inputMapFilename  + "\033[0m): ";
			inputMapFilename = getValidatedFileName(".txt", prompt, 1);
            cout << endl << indent << "	INPUT map details filename successfully set to '\033[31m" << inputMapFilename << "\033[0m'!" << endl;
            break;
        }
        case 'b': {
            string prompt = "Please enter OUTPUT route report filename (current: \033[32m" + outputRouteFilename  + "\033[0m): ";
			outputRouteFilename = getValidatedFileName(".txt", prompt, 1);
            cout << endl << indent << "	OUTPUT route report filename successfully set to '\033[31m" << outputRouteFilename << "\033[0m'!" << endl;
            break;
        }
        case 'c': {
            char criteriaChoice;
            do {
                cout << endl << indent << "		[ Specify Ideal Route Criteria (current: \033[32m" << routeCriteria << "\033[0m) ]\n" << endl;
                cout << indent << "		a) Minimized total energy expenditure" << endl;
                cout << indent << "		b) Shortest distance from Start to End locations" << endl;
                cout << indent << "		c) Go back to sub menu" << endl << endl;
                
                criteriaChoice = getValidatedCharChoice("abc",depth + 2);

                switch (criteriaChoice) {
                case 'a':
                    routeCriteria = "minimized total energy expenditure";
                    cout << indent << "\n		Ideal Route Criteria successfully set to '\033[32m" << routeCriteria << "\033[0m'!" << endl;
                    break;
                case 'b':
                    routeCriteria = "shortest distance from Start to End locations";
                    cout << indent << "\n		Ideal Route Criteria successfully set to '\033[32m" << routeCriteria << "\033[0m'!" << endl;
                    break;
                case 'c':
                    cout << indent << "\n		Going back to sub menu..." << endl;
                    break;
                default:
                    cout << indent << "		Invalid choice! Please try again." << endl;
                    break;
                }
            } while (criteriaChoice != 'c');
            break;
        }
        case 'd': {
            char vehicleChoice;
            do {
                cout << endl << indent << "		[ Specify Vehicle Type (current: \033[32m" << vehicleType << "\033[0m) ]\n" << endl;
                cout << indent << "		a) HighLander (Hill h, Mountain M)" << endl;
                cout << indent << "		b) DragonFly (Swamp w, Watery ~)" << endl;
                cout << indent << "		c) ShieldHero (Danger area X)" << endl;
                cout << indent << "		d) Go back to sub menu" << endl << endl;
                
                vehicleChoice = getValidatedCharChoice("abcd", depth + 2);

                switch (vehicleChoice) {
                case 'a':
                    vehicleType = "HighLander";
                    cout << indent << "\n		Vehicle Type successfully set to '\033[32m" << vehicleType << "\033[0m'!" << endl;
                    break;
                case 'b':
                    vehicleType = "DragonFly";
                    cout << indent << "\n		Vehicle Type successfully set to '\033[32m" << vehicleType << "\033[0m'!" << endl;
                    break;
                case 'c':
                    vehicleType = "ShieldHero";
                    cout << indent << "\n		Vehicle Type successfully set to '\033[32m" << vehicleType << "\033[0m'!" << endl;
                    break;
                case 'd':
                    cout << indent << "\n		Going back to sub menu..." << endl;
                    break;
                default:
                    cout << indent << "\n		Invalid choice! Please try again." << endl;
                    break;
                }
            } while (vehicleChoice != 'd');
            break;
        }
        case 'e':
            cout << indent << "\nGoing back to main menu..." << endl;
            break;
        default:
            cout << indent << "Invalid choice! Please enter a valid option." << endl;
            break;
        }
    } while (choice != 'e');
}

void configureAutopilotSettings(string& inputFilename, bool& isEncrypted, string& outputFilename, int depth)
{
	string indent(depth, '\t');
    char choice;
    do {
        cout << endl << indent << "	[ Configure Autopilot Mapping Exploration settings ]\n" << endl;
        cout << indent << "	a) Specify INPUT scenario filename (current: \033[32m" << inputFilename << "\033[0m)" << endl;
        cout << indent << "	b) Specify INPUT scenario file encrypted (current: \033[32m" << (isEncrypted ? "Y" : "N") << "\033[0m)" << endl;
        cout << indent << "	c) Specify OUTPUT map report filename (current: \033[32m" << outputFilename << "\033[0m)" << endl;
        cout << indent << "	d) Back to main menu" << endl << endl;

        choice = getValidatedCharChoice("abcd",depth + 1);

        switch (choice) {
        case 'a': {
            string prompt = "Please enter INPUT scenario filename (current: \033[32m" + inputFilename  + "\033[0m): ";
			inputFilename = getValidatedFileName(".dat", prompt, 1);
            cout << endl << indent << "	INPUT scenario filename successfully set to '\033[31m" << inputFilename << "\033[0m'!" << endl;
            break;
        }
        case 'b': {
            char encryptChoice;
            encryptChoice = getValidatedCharChoice("YynN", depth + 1);
            isEncrypted = (encryptChoice == 'Y' || encryptChoice == 'y');
            cout << indent << "\n	INPUT scenario file encryption set to '\033[31m" << (isEncrypted ? "Y" : "N") << "\033[0m'!" << endl;
            break;
        }
        case 'c': {
            string prompt = "Please enter OUTPUT map report filename (current: \033[32m" + outputFilename + "\033[0m): ";
			outputFilename = getValidatedFileName(".txt", prompt, 1);
            cout << endl << indent << "	OUTPUT map report filename successfully set to '\033[31m" << outputFilename << "\033[0m'!" << endl;
            break;
        }
        case 'd':
            cout << indent << "\n	Going back to main menu..." << endl;
            break;
        default:
            cout << indent << "	Invalid choice! Please try again." << endl;
            break;
        }
    } while (choice != 'd');
}


