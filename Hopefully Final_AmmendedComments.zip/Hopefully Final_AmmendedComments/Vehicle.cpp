#include "Vehicle.h"
#include "Functions.h"

#include <iostream>
#include <fstream>
#include <ctime>   // for time(), difftime
using namespace std;

// ===========================
//  Base Vehicle
// ===========================
Vehicle::Vehicle()
    : inputMapFilename(""), outputRouteFilename(""), 
      routeCriteria(""), vehicleType("")
{
    // mapData and routes both default empty
}

// setMapData / getMapData
void Vehicle::setMapData(const vector<vector<GridArea>>& data)
{
    mapData = data;
}
vector<vector<GridArea>> Vehicle::getMapData() const
{
    return mapData;
}

// Setter methods
void Vehicle::setInputMapFilename(const string& fname) {
    inputMapFilename = fname;
}
void Vehicle::setOutputRouteFilename(const string& fname) {
    outputRouteFilename = fname;
}
void Vehicle::setRouteCriteria(const string& crit) {
    routeCriteria = crit;
}
void Vehicle::setVehicleType(const string& vtype) {
    vehicleType = vtype;
}
void Vehicle::setRoutes(const vector<DijkstraResult>& r) {
    routes = r;
}
void Vehicle::setAllReportData(
    const string& inMapFile,
    const string& outFile,
    const string& crit,
    const string& vtype,
    const vector<DijkstraResult>& r
)
{
    inputMapFilename = inMapFile;
    outputRouteFilename = outFile;
    routeCriteria = crit;
    vehicleType = vtype;
    routes = r;
}

std::string Vehicle::getVehicleType() const {
    return vehicleType;
}

// ============================
// displayRouteReport (to console)
// ============================
void Vehicle::displayRouteReport() const
{
    cout << endl;
    cout << "Input map details filename = " << inputMapFilename << endl;
    cout << "OUTPUT route report        = " << outputRouteFilename << endl;
    cout << "Ideal Route Criteria       = " << routeCriteria << endl;
    cout << "Vehicle Type               = " << vehicleType << endl;
    cout << endl;

    time_t simStart = time(nullptr);

    string startTimeStr = "SimStartTime";
    cout << "Start datetime stamp       = " << getCurrentTime()  << endl;

    time_t simEnd = time(nullptr);
    string endTimeStr = "SimEndTime";
    cout << "End datetime stamp         = " << getCurrentTime()  << endl;
    cout << endl;

    int duration = static_cast<int>(difftime(simEnd, simStart));
    int hours   = duration / 3600;
    int minutes = (duration % 3600) / 60;
    int seconds = duration % 60;

    cout << "Total Simulation Duration  = "
         << hours << " hr " << minutes << " min " << seconds << " sec" << endl;
    cout << endl;

    if (routes.empty()) {
        cout << "No routes found from any S to E." << endl;
    }
    else {
        int i = 1;
        for (auto &r : routes)
        {
            cout << "Route #" << i++ << " - From ["
                 << r.startPos.x << "," << r.startPos.y << "]"
                 << " to [" << r.endPos.x << "," << r.endPos.y << "]\n\n";

            cout << "Sequence: ";
            bool first = true;
            for (auto &cell : r.path)
            {
                if (!first) {
                    cout << ", ";
                } else {
                    first = false;
                }
                cout << "[" << cell.getX() << "," << cell.getY() << "]";
            }
            cout << "\n\n";

            cout << r.breakdown << "\n\n";
            printRouteAsMap(r.path);
            cout << "\n"; 
        }
    }
}

// ============================
// printRouteReport (to file)
// ============================
void Vehicle::printRouteReport(const string& outputFilename) const
{
    ofstream out(outputFilename);
    if (!out) {
        cerr << "[Vehicle] Cannot open " << outputFilename << " for writing!\n";
        return;
    }

    out << endl;
    out << "Input map details filename = " << inputMapFilename << endl;
    out << "OUTPUT route report        = " << outputRouteFilename << endl;
    out << "Ideal Route Criteria       = " << routeCriteria << endl;
    out << "Vehicle Type               = " << vehicleType << endl;
    out << endl;

    time_t simStart = time(nullptr);
    string startTimeStr = "SimStartTime";
    out << "Start datetime stamp       = " << getCurrentTime() << endl;

    time_t simEnd = time(nullptr);
    string endTimeStr = "SimEndTime";
    out << "End datetime stamp         = " << getCurrentTime() << endl;
    out << endl;

    int duration = static_cast<int>(difftime(simEnd, simStart));
    int hours   = duration / 3600;
    int minutes = (duration % 3600) / 60;
    int seconds = duration % 60;

    out << "Total Simulation Duration  = "
        << hours << " hr " << minutes << " min " << seconds << " sec" << endl;
    out << endl;

    if (routes.empty()) {
        out << "No routes found from any S to E." << endl;
    }
    else {
        int i = 1;
        for (auto &r : routes)
        {
            out << "Route #" << i++ << " - From ["
                << r.startPos.x << "," << r.startPos.y << "]"
                << " to [" << r.endPos.x << "," << r.endPos.y << "]\n\n";

            out << "Sequence: ";
            bool first = true;
            for (auto &cell : r.path)
            {
                if (!first) {
                    out << ", ";
                } else {
                    first = false;
                }
                out << "[" << cell.getX() << "," << cell.getY() << "]";
            }
            out << "\n\n";

            // r.breakdown
            out << r.breakdown << "\n\n";
            printRouteAsMap(out, r.path, maparr);
            cout << "\n";
        }
    }

    out.close();
}

// ============================
// computeAllIdealRoutes
// ============================
vector<DijkstraResult> Vehicle::computeAllIdealRoutes() const
{
    // Possibly just return routes or do something else
    return routes;
}

// ============================
// HighLander 
// ============================

HighLander::HighLander() : Vehicle() {}
void HighLander::displayRouteReport() const {
    cout << "[HighLander] Display Route Report\n";
    Vehicle::displayRouteReport();
}
void HighLander::printRouteReport(const string& filename) const {
    Vehicle::printRouteReport(filename);
}
vector<DijkstraResult> HighLander::computeAllIdealRoutes() const {
    return routes;  // or do real logic
}
bool HighLander::canTraverseTerrain(char terrainSymbol) const
{
    // Example logic: anything except barrier '#'
    return (terrainSymbol != '#');
}

bool HighLander::isPreferredTerrain(char terrainSymbol) const
{
    // Example logic: 'h' (hill) and 'M' (mountain) are preferred
    return (terrainSymbol == 'h' || terrainSymbol == 'M');
}

// ============================
// DragonFly
// ============================

DragonFly::DragonFly() : Vehicle() {}
void DragonFly::displayRouteReport() const {
    cout << "[DragonFly] Display Route Report\n";
    Vehicle::displayRouteReport();
}
void DragonFly::printRouteReport(const string& filename) const {
    Vehicle::printRouteReport(filename);
}
vector<DijkstraResult> DragonFly::computeAllIdealRoutes() const {
    return routes;
}
bool DragonFly::canTraverseTerrain(char terrainSymbol) const
{
    return (terrainSymbol != '#');
}

bool DragonFly::isPreferredTerrain(char terrainSymbol) const
{
    // Example logic: 'w' (water) and '~' (swamp) are preferred
    return (terrainSymbol == 'w' || terrainSymbol == '~');
}

// ============================
// ShieldHero
// ============================

ShieldHero::ShieldHero() : Vehicle() {}
void ShieldHero::displayRouteReport() const {
    cout << "[ShieldHero] Display Route Report\n";
    Vehicle::displayRouteReport();
}
void ShieldHero::printRouteReport(const string& filename) const {
    Vehicle::printRouteReport(filename);
}
vector<DijkstraResult> ShieldHero::computeAllIdealRoutes() const {
    return routes;
}
bool ShieldHero::canTraverseTerrain(char terrainSymbol) const
{
    return (terrainSymbol != '#');
}

bool ShieldHero::isPreferredTerrain(char terrainSymbol) const
{
    // Example logic: 'X' (danger zone) is preferred
    return (terrainSymbol == 'X');
}
