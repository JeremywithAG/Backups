#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include <iostream>
#include <string>
#include <vector>
#include <climits>

#include "GridArea.h"
#include "Functions.h" 

using namespace std;

struct MyThing {
    Position* posPtr; // pointer
};

struct DijkstraResult 
{
    std::vector<GridArea> path;
    long cost;
    std::string breakdown;
    // Optional extra fields:
    Position startPos;
    Position endPos;
};

//findpath
DijkstraResult buildRouteCostBreakdown(const std::vector<GridArea>& route);
void printRouteAsMap(const vector<GridArea>& route);
void printRouteAsMap(std::ostream& out,
    const std::vector<GridArea>& route,
    const std::vector<std::vector<char>>& maparr);
std::vector<DijkstraResult> computeAllDijkstraRoutes();
std::vector<DijkstraResult> computeAllMinEnergyRoutes();
std::vector<GridArea> findBestRouteThroughPreferredDijkstra(
    const Position &S,
    const Position &E,
    const std::vector<Position> &allPreferred);
std::vector<GridArea> findBestRouteThroughPreferredMinEnergy(
        const Position &S,
        const Position &E,
        const std::vector<Position> &allPreferred);


#endif