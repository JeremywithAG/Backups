#include <iostream>
#include <fstream>
#include <vector>

#include "Functions.h"
#include "SatComRelay.h"
#include "VehData.h"
#include "GridArea.h"

using namespace std;



int width = 4;
int height = 4;

int vehiclex = width / 2;  // Start in center
int vehicley = height / 2;

std::vector<std::vector<char>> maparr;

void mapinit()
{
    maparr = std::vector<std::vector<char>>(width, std::vector<char>(height, ' '));
}

void checkAndExpand() 
{
    // Expand left if at x <= 1 (scanning west or NW/SW WILL NOT go out of range).
    if (vehiclex <= 1) {
        for (auto& row : maparr) {
            row.insert(row.begin(), ' ');
        }
        width++;
        vehiclex++;
    }

    // Expand right if near right edge.
    if (vehiclex >= width - 2) {
        for (auto& row : maparr) {
            row.push_back(' ');
        }
        width++;
    }

    // Expand top near y <= 1.
    if (vehicley <= 1) {
        maparr.insert(maparr.begin(), std::vector<char>(width, ' '));
        height++;
        vehicley++;
    }

    // Expand bottom near y >= height - 2.
    if (vehicley >= height - 2) {
        maparr.push_back(std::vector<char>(width, ' '));
        height++;
    }
}

void prepareMapForScan() {
    // Expand all directions twice to provide safe buffer zone
    for (int i = 0; i < 2; ++i) {
        checkAndExpand();
    }
}

void mapprint() 
{
    if (maparr.empty()) return;

    int rows = maparr.size();
    int cols = maparr[0].size();

    // Print column headers
    cout << "   ";
    for (int x = 0; x < cols; x++) 
    {
        if (x < 10) cout << " " << x << " ";
        else        cout << x << " ";
    }
    cout << "\n";

    // Print each row
    for (int y = 0; y < rows; y++) 
    {
        if (y < 10) cout << " " << y << " ";
        else        cout << y << " ";

        for (int x = 0; x < cols; x++) 
        {
            if (maparr[y][x] == ' ')
            cout << "   ";
            else
            cout << " " << maparr[y][x] << " ";
        }
        cout << "\n";
    }
}

void writeRawMapToFile(const std::string &filename)
{
    std::ofstream outFile(filename);
    if (!outFile)
    {
        std::cerr << "Error: could not open " << filename << " for writing.\n";
        return;
    }


    // print each row’s characters 
    for (int y = 0; y < (int)maparr.size(); ++y)
    {
        for (int x = 0; x < (int)maparr[y].size(); ++x)
        {
            outFile << maparr[y][x];
        }
        outFile << "\n";
    }
    outFile.close();
}
