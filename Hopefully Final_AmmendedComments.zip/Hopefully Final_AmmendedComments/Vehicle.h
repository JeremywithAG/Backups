#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>
#include <vector>
#include "Functions.h"
#include "GridArea.h"
#include "Dijkstra.h"


using namespace std;

class Vehicle
{
protected:
    vector<vector<GridArea>> mapData;

    string inputMapFilename;
    string outputRouteFilename;
    string routeCriteria;
    string vehicleType;

    vector<DijkstraResult> routes;

public:
    Vehicle();
    virtual ~Vehicle() = default;

    // setMapData/getMapData, setRoutes, etc...
    void setMapData(const vector<vector<GridArea>>& data);
    vector<vector<GridArea>> getMapData() const;

    void setInputMapFilename(const string& fname);
    void setOutputRouteFilename(const string& fname);
    void setRouteCriteria(const string& crit);
    void setVehicleType(const string& vtype);
    void setRoutes(const vector<DijkstraResult>& r);

    void setAllReportData(
        const string& inMapFile,
        const string& outFile,
        const string& crit,
        const string& vtype,
        const vector<DijkstraResult>& r
    );

    std::string getVehicleType() const;

    // Prints to console
    virtual void displayRouteReport() const;

    // Prints to file
    virtual void printRouteReport(const string& outputFilename) const;

    // If you have pathfinding
    virtual vector<DijkstraResult> computeAllIdealRoutes() const;

    virtual bool canTraverseTerrain(char terrainSymbol) const = 0;
    virtual bool isPreferredTerrain(char terrainSymbol) const = 0;
};

// ===========================
//   HighLander
// ===========================
class HighLander : public Vehicle
{
public:
    HighLander();

    // Possibly store unique logic for route computations, display, etc.
    void displayRouteReport() const override;
    void printRouteReport(const string& outputFilename) const override;
    vector<DijkstraResult> computeAllIdealRoutes() const override;
    bool canTraverseTerrain(char terrainSymbol) const override;
    bool isPreferredTerrain(char terrainSymbol) const override;
};

// ===========================
//   DragonFly
// ===========================
class DragonFly : public Vehicle
{
public:
    DragonFly();

    void displayRouteReport() const override;
    void printRouteReport(const string& outputFilename) const override;
    vector<DijkstraResult> computeAllIdealRoutes() const override;
    bool canTraverseTerrain(char terrainSymbol) const override;
    bool isPreferredTerrain(char terrainSymbol) const override;
};

// ===========================
//   ShieldHero
// ===========================
class ShieldHero : public Vehicle
{
public:
    ShieldHero();

    void displayRouteReport() const override;
    void printRouteReport(const string& outputFilename) const override;
    vector<DijkstraResult> computeAllIdealRoutes() const override;
    bool canTraverseTerrain(char terrainSymbol) const override;
    bool isPreferredTerrain(char terrainSymbol) const override;
};

#endif
