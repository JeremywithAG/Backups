#include <iostream>
#include <string>
#include <ctime>

#include "SatComRelay.h"
#include "Functions.h"
#include "VehData.h"
#include "GridArea.h"
#include "Vehicle.h"
#include "Dijkstra.h"

using namespace std;

Vehicle* activeVehicle = nullptr;
SatComRelay relay;
VehData vehicleData;

int main()
{
    string inputFilename      = "Scenario06.dat";  // used by autopilot
    bool   isEncrypted        = true;
    bool   randomizeStartPos  = false;
    string outputFilename     = "map-rpt.txt";

    string inputMapFilename   = "map-rpt.txt";
    string outputRouteFilename= "route-rpt.txt";
    string routeCriteria      = "shortest distance from Start to End locations";
    string vehicleType        = "ShieldHero";

    int choice;
    do 
    {
        displayMainMenu(1, "Alexandre Cotton",0);
        choice = getValidatedChoice(1, 5);
        
        mapinit();

        switch (choice) 
        {
            case 1:
            {
                configureAutopilotSettings(inputFilename, isEncrypted, outputFilename);
                break;
            }
            case 2:
            {
                configureSimulatorSettings(inputMapFilename, outputRouteFilename, routeCriteria, vehicleType);
                break;
            }
            case 3:
            {
                int missionType = 999999;
                init(inputFilename, isEncrypted, randomizeStartPos, missionType);
                automap(inputFilename, isEncrypted, outputFilename);  
                break;
            }
            case 4:
            {
                if (activeVehicle != nullptr) {
                    delete activeVehicle;
                    activeVehicle = nullptr;
                }

                if (vehicleType == "HighLander") {
                    activeVehicle = new HighLander();
                }
                else if (vehicleType == "DragonFly") {
                    activeVehicle = new DragonFly();
                }
                else {
                    activeVehicle = new ShieldHero();
                }

                vector<vector<char>> charMap = parseMapFromFile(inputMapFilename);

                vector<vector<GridArea>> grid = convertCharMapToGridArea(charMap);

                activeVehicle->setMapData(grid);

                maparr = charMap;

                
                activeVehicle->setInputMapFilename(inputMapFilename);
                activeVehicle->setOutputRouteFilename(outputRouteFilename);
                activeVehicle->setRouteCriteria(routeCriteria);
                activeVehicle->setVehicleType(vehicleType);

                
                vector<DijkstraResult> routes;
                if (routeCriteria == "shortest distance from Start to End locations")
                {
                    routes = computeAllDijkstraRoutes();
                    activeVehicle->setRoutes(routes);
                }
                else
                {
                    routes = computeAllMinEnergyRoutes();
                    activeVehicle->setRoutes(routes);
                }

                activeVehicle->displayRouteReport();

                activeVehicle->printRouteReport(outputRouteFilename);

                break;
            }
            case 5:
            {
                cout << "Exiting program..." << endl;
                break;
            }
            default:
            {
                cout << "Invalid choice! Please enter a number between 1-5." << endl;
                break;
            }
        }
    } while (choice != 5);

    if (activeVehicle != nullptr) 
    {
        delete activeVehicle;
        activeVehicle = nullptr;
    }
    return 0;
}
