#include "Vehicle.h"
#include "Functions.h"
#include "Dijkstra.h"
#include "GridArea.h"


#include <queue>
#include <vector>
#include <climits>
#include <iostream>
#include <algorithm>
#include <iomanip>

using namespace std;


extern Vehicle* activeVehicle;  // from Main.cpp
extern vector<vector<char>> maparr;


// struct for Dijkstra 
// use cost=number_of_steps, each step is +1
struct Node 
{
    int x, y;
    long cost; 
    Node(int _x, int _y, long _cost) : x(_x), y(_y), cost(_cost) {}
    bool operator>(const Node& other) const {
        return cost > other.cost;
    }
};


// runDijkstra: pathfinding from single S to single E
//              step-count 1 step = cost 1
static vector<GridArea> runDijkstra(const Position& startPos, const Position& endPos)
{
    int rows = (int)maparr.size();
    if (rows == 0) return {};
    int cols = (int)maparr[0].size();

    // Basic bounds checks
    if (startPos.x < 0 || startPos.x >= cols ||
        startPos.y < 0 || startPos.y >= rows ||
        endPos.x   < 0 || endPos.x   >= cols ||
        endPos.y   < 0 || endPos.y   >= rows)
    {
        cerr << "[runDijkstra] Invalid S/E coords.\n";
        return {};
    }

    // Dijkstra data structures
    vector<vector<long>> dist(rows, vector<long>(cols, LONG_MAX));
    vector<vector<pair<int,int>>> prev(rows, vector<pair<int,int>>(cols, {-1, -1}));

    // Min-heap (priority queue) for (x, y, costSoFar)
    priority_queue<Node, vector<Node>, greater<Node>> pq;

    // Initialize starting cell
    dist[startPos.y][startPos.x] = 0;
    pq.push(Node(startPos.x, startPos.y, 0));

    // 4-direction moves
    static const vector<pair<int,int>> directions = {
        {0,-1}, {0,1}, {-1,0}, {1,0}
    };

    while (!pq.empty())
    {
        Node curr = pq.top();
        pq.pop();

        int x = curr.x;
        int y = curr.y;
        long currDist = curr.cost;

        // If reached End, done
        if (x == endPos.x && y == endPos.y) {
            break;
        }

        // If outdated cost, skip
        if (currDist > dist[y][x]) {
            continue;
        }

        // Explore neighbours
        for (auto [dx, dy] : directions)
        {
            int nx = x + dx;
            int ny = y + dy;

            // Check boundaries
            if (nx < 0 || ny < 0 || nx >= cols || ny >= rows)
                continue;

            // Check if passable (skip '#' or whatever vehicle not able to traverse)
            char terrainSym = maparr[ny][nx];
            if (!activeVehicle->canTraverseTerrain(terrainSym)) {
                continue;
            }

            // Each step costs exactly 1 (shortest path by steps only)
            long newDist = currDist + 1;

            if (newDist < dist[ny][nx]) {
                dist[ny][nx] = newDist;
                prev[ny][nx] = {x, y};
                pq.push(Node(nx, ny, newDist));
            }
        }
    }

    // If unreachable, dist[endPos.y][endPos.x] stays LONG_MAX
    if (dist[endPos.y][endPos.x] == LONG_MAX) {
        return {};
    }

    // Reconstruct the route by backtracking from endPos
    vector<GridArea> route;
    int cx = endPos.x;
    int cy = endPos.y;

    while (cx != -1 && cy != -1)
    {
        char sym = maparr[cy][cx];
        route.push_back(GridArea(cx, cy, GridArea::convertCharToTerrainType(sym)));
        auto [px, py] = prev[cy][cx];
        cx = px;
        cy = py;
    }

    reverse(route.begin(), route.end());
    return route;
}


// computeAllDijkstraRoutes:
//   -finds shortest path (by step count) from each S to each E
//   -then calculates & prints both non-discounted and discounted energy
std::vector<DijkstraResult> computeAllDijkstraRoutes()
{
    std::vector<DijkstraResult> allRoutes;

    // Collect all S and E
    auto [allStarts, allEnds] = findAllStartAndEndPositions();
    if (allStarts.empty() || allEnds.empty())
    {
        std::cerr << "[computeAllDijkstraRoutes] No S or E found.\n";
        return allRoutes;
    }

    // Gather all preferred cells for activeVehicle
    std::vector<Position> allPreferred;
    for (int y = 0; y < (int)maparr.size(); ++y)
    {
        for (int x = 0; x < (int)maparr[y].size(); ++x)
        {
            if (activeVehicle->isPreferredTerrain(maparr[y][x]))
            {
                allPreferred.push_back(Position(x, y));
            }
        }
    }
    bool mapHasPreferred = !allPreferred.empty();

    // For each S/E
    for (auto &sPos : allStarts)
    {
        for (auto &ePos : allEnds)
        {
            // A) Get direct route
            std::vector<GridArea> directRoute = runDijkstra(sPos, ePos);
            if (directRoute.empty())
                continue; // if cannot reach E from S at all

            // B) Check if direct route has preferred cell
            bool directHasPreferred = false;
            if (mapHasPreferred)
            {
                for (auto &cell : directRoute)
                {
                    char sym = maparr[cell.getY()][cell.getX()];
                    if (activeVehicle->isPreferredTerrain(sym))
                    {
                        directHasPreferred = true;
                        break;
                    }
                }
            }

            std::vector<GridArea> finalRoute = directRoute;

            if (mapHasPreferred && !directHasPreferred)
            {
                // Phase B: forced route
                std::vector<GridArea> forced = findBestRouteThroughPreferredDijkstra(sPos, ePos, allPreferred);
                if (!forced.empty())
                {
                    finalRoute = forced;
                }
                else
                {
                    // If forced is empty, skip entirely
                    // No direct route with preferred, no forced route => skip
                    continue;
                }
            }

            // build cost breakdown 
            DijkstraResult dr = buildRouteCostBreakdown(finalRoute);
            dr.startPos = sPos;
            dr.endPos   = ePos;
            allRoutes.push_back(dr);
        }
    }

    return allRoutes;
}

static vector<GridArea> runDijkstraMinEnergy(const Position& startPos, const Position& endPos)
{
    int rows = (int)maparr.size();
    if (rows == 0) return {};
    int cols = (int)maparr[0].size();

    // Basic bounds checks
    if (startPos.x < 0 || startPos.x >= cols ||
        startPos.y < 0 || startPos.y >= rows ||
        endPos.x   < 0 || endPos.x   >= cols ||
        endPos.y   < 0 || endPos.y   >= rows)
    {
        cerr << "[runDijkstraMinEnergy] Invalid S/E coords.\n";
        return {};
    }

    // Dijkstra data structures
    vector<vector<long>> dist(rows, vector<long>(cols, LONG_MAX));
    vector<vector<pair<int,int>>> prev(rows, vector<pair<int,int>>(cols, {-1, -1}));

    // Min-heap (priority queue) for (x, y, costSoFar)
    priority_queue<Node, vector<Node>, greater<Node>> pq;

    // Initialize starting cell
    dist[startPos.y][startPos.x] = 0;
    pq.push(Node(startPos.x, startPos.y, 0));

    // 4-direction moves
    static const vector<pair<int,int>> directions = {
        {0,-1}, {0,1}, {-1,0}, {1,0}
    };

    while (!pq.empty())
    {
        Node curr = pq.top();
        pq.pop();

        int x = curr.x;
        int y = curr.y;
        long currDist = curr.cost;

        // If reached End, can stop
        if (x == endPos.x && y == endPos.y) {
            break;
        }

        // If outdated cost, skip
        if (currDist > dist[y][x]) {
            continue;
        }

        // Explore neighbours
        for (auto [dx, dy] : directions)
        {
            int nx = x + dx;
            int ny = y + dy;

            // Check boundaries
            if (nx < 0 || ny < 0 || nx >= cols || ny >= rows)
                continue;

            // Check if passable
            char terrainSym = maparr[ny][nx];
            if (!activeVehicle->canTraverseTerrain(terrainSym)) {
                continue;
            }

            // Compute the cost to step onto terrainSym
            long costToMove = 0;
            if (terrainSym != 'S' && terrainSym != 'E')
            {
                long rawCost = getMovementCostForSymbol(terrainSym);
                if (activeVehicle->isPreferredTerrain(terrainSym)) {
                    rawCost /= 2; // discount for preferred
                }
                costToMove = rawCost;
            }

            long newDist = currDist + costToMove;

            if (newDist < dist[ny][nx]) {
                dist[ny][nx] = newDist;
                prev[ny][nx] = {x, y};
                pq.push(Node(nx, ny, newDist));
            }
        }
    }

    // If unreachable, dist[endPos.y][endPos.x] stays LONG_MAX
    if (dist[endPos.y][endPos.x] == LONG_MAX) {
        return {};
    }

    // Reconstruct route by backtracking from endPos
    vector<GridArea> route;
    int cx = endPos.x;
    int cy = endPos.y;

    while (cx != -1 && cy != -1)
    {
        char sym = maparr[cy][cx];
        route.push_back(GridArea(cx, cy, GridArea::convertCharToTerrainType(sym)));
        auto [px, py] = prev[cy][cx];
        cx = px;
        cy = py;
    }

    reverse(route.begin(), route.end());
    return route;
}


// computeAllMinEnergyRoutes:
//   * finds minimum total energy path (with discount logic)
//     from each S to each E
std::vector<DijkstraResult> computeAllMinEnergyRoutes()
{
    std::vector<DijkstraResult> allRoutes;

    auto [allStarts, allEnds] = findAllStartAndEndPositions();
    if (allStarts.empty() || allEnds.empty())
    {
        std::cerr << "[computeAllMinEnergyRoutes] No S or E found.\n";
        return allRoutes;
    }

    // Gather all preferred cells
    std::vector<Position> allPreferred;
    for (int y = 0; y < (int)maparr.size(); ++y)
    {
        for (int x = 0; x < (int)maparr[y].size(); ++x)
        {
            if (activeVehicle->isPreferredTerrain(maparr[y][x]))
            {
                allPreferred.push_back(Position(x, y));
            }
        }
    }
    bool mapHasPreferred = !allPreferred.empty();

    // For each S/E
    for (auto &sPos : allStarts)
    {
        for (auto &ePos : allEnds)
        {
            // A) Direct route (energy-based)
            std::vector<GridArea> directRoute = runDijkstraMinEnergy(sPos, ePos);
            if (directRoute.empty())
                continue;

            bool directHasPreferred = false;
            if (mapHasPreferred)
            {
                for (auto &cell : directRoute)
                {
                    char sym = maparr[cell.getY()][cell.getX()];
                    if (activeVehicle->isPreferredTerrain(sym))
                    {
                        directHasPreferred = true;
                        break;
                    }
                }
            }

            std::vector<GridArea> finalRoute = directRoute;

            // If direct route has no preferred cell but map have them,
            // force a route that hits at least one
            if (mapHasPreferred && !directHasPreferred)
            {
                std::vector<GridArea> forced = findBestRouteThroughPreferredMinEnergy(sPos, ePos, allPreferred);
                if (!forced.empty())
                {
                    finalRoute = forced;
                }
                else
                {
                    // no forced path => skip
                    continue;
                }
            }

            // Build cost breakdown
            DijkstraResult dr = buildRouteCostBreakdown(finalRoute);
            dr.startPos = sPos;
            dr.endPos   = ePos;
            allRoutes.push_back(dr);
        }
    }

    return allRoutes;
}




void printRouteAsMap(const vector<GridArea>& route)
{
    if (maparr.empty()) return;

    int rows = (int)maparr.size();
    int cols = (int)maparr[0].size();
    vector<vector<char>> displayMap(rows, vector<char>(cols, ' '));

    // Mark route cells
    for (auto &cell : route)
    {
        displayMap[cell.getY()][cell.getX()] = maparr[cell.getY()][cell.getX()];
    }

    // Also mark S, E, and '#' on the map
    for (int y = 0; y < rows; ++y)
    {
        for (int x = 0; x < cols; ++x)
        {
            if (maparr[y][x] == 'S' || maparr[y][x] == 'E' || maparr[y][x] == '#')
            {
                displayMap[y][x] = maparr[y][x];
            }
        } 
    }

    // Print column headers with extra spacing
    cout << "     "; // Space for row header
    for (int col = 0; col < cols; ++col)
    {
        cout << setw(3) << col;
    }
    cout << "\n\n";

    // Print each row with its row header
    for (int row = 0; row < rows; ++row)
    {
        cout << setw(3) << row << "  "; // Row header with extra spacing
        for (int col = 0; col < cols; ++col)
        {
            cout << setw(3) << displayMap[row][col];
        }
        cout << "\n";
    }
}

void printRouteAsMap(std::ostream& out,
                     const std::vector<GridArea>& route,
                     const std::vector<std::vector<char>>& maparr)
{
    if (maparr.empty()) return;

    int rows = (int)maparr.size();
    int cols = (int)maparr[0].size();

    // Create blank display grid filled with spaces
    std::vector<std::vector<char>> display(rows, std::vector<char>(cols, ' '));

    // Mark path cells in 'display' 
    for (auto &cell : route)
    {
        int y = cell.getY();
        int x = cell.getX();

        display[y][x] = maparr[y][x];
    }

    // show #, S, E, etc. even if not in path:
    // else, skip 
    for (int y = 0; y < rows; ++y)
    {
        for (int x = 0; x < cols; ++x)
        {
            // For example, show barrier, start, end:
            if (maparr[y][x] == '#' || maparr[y][x] == 'S' || maparr[y][x] == 'E')
            {
                display[y][x] = maparr[y][x];
            }
        }
    }

    // Now print 'display' array.
   
    out << "     "; // spacing for top-left
    for (int col = 0; col < cols; ++col)
    {
        out << std::setw(3) << col;
    }
    out << "\n\n";

    for (int row = 0; row < rows; ++row)
    {
        out << std::setw(3) << row << "  ";
        for (int col = 0; col < cols; ++col)
        {
            out << std::setw(3) << display[row][col];
        }
        out << "\n";
    }
}

std::vector<GridArea> combineRoutes(const std::vector<GridArea> &pathA,
    const std::vector<GridArea> &pathB)
{
if (pathA.empty()) return pathB;
if (pathB.empty()) return pathA;

// last cell of pathA and  first cell of pathB should be same cell
std::vector<GridArea> combined = pathA;
// Pop duplicate
combined.pop_back();
// Then append pathB
combined.insert(combined.end(), pathB.begin(), pathB.end());
return combined;
}

std::vector<GridArea> findBestRouteThroughPreferredDijkstra(
    const Position &S,
    const Position &E,
    const std::vector<Position> &allPreferred)
{
    long bestCost = LONG_MAX;
    std::vector<GridArea> bestRoute;

    // For each preferred cell p in the map
    for (auto &p : allPreferred)
    {
        // route S->p by step-count
        std::vector<GridArea> routeSP = runDijkstra(S, p);
        if (routeSP.empty()) 
            continue; // can't reach p

        // route p->E by step-count
        std::vector<GridArea> routePE = runDijkstra(p, E);
        if (routePE.empty())
            continue; // can't reach E from p

        // Combine them
        // cost is routeSP.size() + routePE.size(),
        // minus 1 to avoid double-counting shared cell p.
        std::vector<GridArea> fullPath = combineRoutes(routeSP, routePE);

        long totalSteps = (long)fullPath.size() - 1; 
        // (Because if we have N cells in a path, the "step count" is N-1 steps.)
        if (totalSteps < bestCost)
        {
            bestCost = totalSteps;
            bestRoute = fullPath;
        }
    }
    return bestRoute;
}

std::vector<GridArea> findBestRouteThroughPreferredMinEnergy(
    const Position &S,
    const Position &E,
    const std::vector<Position> &allPreferred)
{
    long bestCost = LONG_MAX;
    std::vector<GridArea> bestRoute;

    for (auto &p : allPreferred)
    {
        // route S->p
        std::vector<GridArea> routeSP = runDijkstraMinEnergy(S, p);
        if (routeSP.empty()) 
            continue;

        // route p->E
        std::vector<GridArea> routePE = runDijkstraMinEnergy(p, E);
        if (routePE.empty())
            continue;

        // combine them
        std::vector<GridArea> fullPath = combineRoutes(routeSP, routePE);

        // compute cost for the combined path
        DijkstraResult tempDR = buildRouteCostBreakdown(fullPath);
        long totalDiscountedCost = tempDR.cost; 
        if (totalDiscountedCost < bestCost)
        {
            bestCost = totalDiscountedCost;
            bestRoute = fullPath;
        }
    }
    return bestRoute;
}

DijkstraResult buildRouteCostBreakdown(const std::vector<GridArea> &route)
{
    DijkstraResult result;
    result.path = route; 


    long totalNoDiscount = 0;
    long totalDiscount   = 0;

    std::ostringstream breakdownNoDisc;
    std::ostringstream breakdownDisc;
    bool firstNoDisc = true, firstDisc = true;

    int preferredCount = 0;
    int totalTraversed = 0;

    for (auto &cell : route)
    {
        char sym = maparr[cell.getY()][cell.getX()];
        if (sym == 'S' || sym == 'E') 
            continue;

        totalTraversed++;
        long rawCost = getMovementCostForSymbol(sym);

        // Non-discounted
        if (!firstNoDisc) breakdownNoDisc << " + ";
        breakdownNoDisc << sym << "(" << rawCost << ")";
        firstNoDisc = false;
        totalNoDiscount += rawCost;

        // Discounted
        long discCost = rawCost;
        if (activeVehicle->isPreferredTerrain(sym))
        {
            discCost /= 2;
            preferredCount++;
        }
        if (!firstDisc) breakdownDisc << " + ";
        breakdownDisc << sym << "(" << discCost << ")";
        firstDisc = false;
        totalDiscount += discCost;
    }

    std::ostringstream final;
    final << "Preferred Terrain Count = " << preferredCount << "\n"
          << "Total Terrain Traversed = " << totalTraversed << "\n"
          << "Total Movt Enrg reqd (Generic Veh) = "
          << breakdownNoDisc.str() << " = " << totalNoDiscount << "\n"
          << "Total Movt Enrg reqd (" << activeVehicle->getVehicleType() << ")  = "
          << breakdownDisc.str() << " = " << totalDiscount;

    result.cost      = totalDiscount;   // discount or noDiscount
    result.breakdown = final.str();
    return result;
}
