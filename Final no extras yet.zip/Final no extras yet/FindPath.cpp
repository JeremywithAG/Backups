#include "Functions.h"
#include "GridArea.h"
#include "Vehicle.h" // so we can reference activeVehicle

#include <queue>
#include <vector>
#include <climits>
#include <iostream>
#include <algorithm>
#include <iomanip>

using namespace std;

// Extern globals
extern Vehicle* activeVehicle;  // from Main.cpp
extern vector<vector<char>> maparr;

// ----------------------------------------------------------
// Helper struct for our Dijkstra priority queue
// (Here we just use cost=number_of_steps, so each step is +1.)
// ----------------------------------------------------------
struct Node 
{
    int x, y;
    long cost; 
    Node(int _x, int _y, long _cost) : x(_x), y(_y), cost(_cost) {}
    bool operator>(const Node& other) const {
        return cost > other.cost;
    }
};

// ----------------------------------------------------------
// runDijkstra: pathfinding from a single S to a single E
//              purely by step-count (1 step = cost 1).
// ----------------------------------------------------------
static vector<GridArea> runDijkstra(const Position& startPos, const Position& endPos)
{
    int rows = (int)maparr.size();
    if (rows == 0) return {};
    int cols = (int)maparr[0].size();

    // Basic bounds checks
    if (startPos.x < 0 || startPos.x >= cols ||
        startPos.y < 0 || startPos.y >= rows ||
        endPos.x   < 0 || endPos.x   >= cols ||
        endPos.y   < 0 || endPos.y   >= rows)
    {
        cerr << "[runDijkstra] Invalid S/E coords.\n";
        return {};
    }

    // Dijkstra data structures
    vector<vector<long>> dist(rows, vector<long>(cols, LONG_MAX));
    vector<vector<pair<int,int>>> prev(rows, vector<pair<int,int>>(cols, {-1, -1}));

    // Min-heap (priority queue) for (x, y, costSoFar)
    priority_queue<Node, vector<Node>, greater<Node>> pq;

    // Initialize starting cell
    dist[startPos.y][startPos.x] = 0;
    pq.push(Node(startPos.x, startPos.y, 0));

    // 4-direction moves
    static const vector<pair<int,int>> directions = {
        {0,-1}, {0,1}, {-1,0}, {1,0}
    };

    while (!pq.empty())
    {
        Node curr = pq.top();
        pq.pop();

        int x = curr.x;
        int y = curr.y;
        long currDist = curr.cost;

        // If we've reached End, we're done
        if (x == endPos.x && y == endPos.y) {
            break;
        }

        // If outdated cost, skip
        if (currDist > dist[y][x]) {
            continue;
        }

        // Explore neighbors
        for (auto [dx, dy] : directions)
        {
            int nx = x + dx;
            int ny = y + dy;

            // Check boundaries
            if (nx < 0 || ny < 0 || nx >= cols || ny >= rows)
                continue;

            // Check if passable (skip '#' or whatever else the vehicle can't traverse)
            char terrainSym = maparr[ny][nx];
            if (!activeVehicle->canTraverseTerrain(terrainSym)) {
                continue;
            }

            // Each step costs exactly 1 (shortest path by steps only)
            long newDist = currDist + 1;

            if (newDist < dist[ny][nx]) {
                dist[ny][nx] = newDist;
                prev[ny][nx] = {x, y};
                pq.push(Node(nx, ny, newDist));
            }
        }
    }

    // If unreachable, dist[endPos.y][endPos.x] stays LONG_MAX
    if (dist[endPos.y][endPos.x] == LONG_MAX) {
        return {};
    }

    // Reconstruct the route by backtracking from endPos
    vector<GridArea> route;
    int cx = endPos.x;
    int cy = endPos.y;

    while (cx != -1 && cy != -1)
    {
        char sym = maparr[cy][cx];
        route.push_back(GridArea(cx, cy, GridArea::convertCharToTerrainType(sym)));
        auto [px, py] = prev[cy][cx];
        cx = px;
        cy = py;
    }

    reverse(route.begin(), route.end());
    return route;
}

// ----------------------------------------------------------
// computeAllDijkstraRoutes:
//   * finds the *shortest path* (by step count) from each S to each E
//   * then calculates & prints both non-discounted and discounted energy
//     but that does NOT affect route selection
// ----------------------------------------------------------
std::vector<DijkstraResult> computeAllDijkstraRoutes()
{
    // Collect all S and E from the map
    auto [allStarts, allEnds] = findAllStartAndEndPositions();
    std::vector<DijkstraResult> allRoutes;

    // If no S or E found, just return empty
    if (allStarts.empty() || allEnds.empty()) {
        cerr << "[computeAllDijkstraRoutes] No S or E found.\n";
        return {};
    }

    // For each start, for each end
    for (auto &sPos : allStarts)
    {
        for (auto &ePos : allEnds)
        {
            // Use runDijkstra to get a purely step-based path
            vector<GridArea> attempt = runDijkstra(sPos, ePos);

            // If we actually found a path
            if (!attempt.empty())
{
    // We'll compute both non-discounted total AND discounted total
    long totalNoDiscount = 0;
    long totalDiscount   = 0;
    
    // We'll store each symbol's cost for display (for each route)
    std::ostringstream breakdownStreamNoDisc;
    std::ostringstream breakdownStreamDisc;
    
    bool firstNoDisc = true;
    bool firstDisc   = true;
    
    // NEW: Counters for preferred terrains and total terrain traversed
    int preferredCount = 0;
    int totalTraversed = 0;
    
    for (auto &cell : attempt)
    {
        char sym = maparr[cell.getY()][cell.getX()];
        
        // Exclude S and E from cost calculations and counting
        if (sym == 'S' || sym == 'E') {
            continue;
        }
        
        // Count every traversed terrain cell
        totalTraversed++;
        
        long rawCost = getMovementCostForSymbol(sym);
        
        // 1) Non-discounted breakdown
        if (!firstNoDisc) {
            breakdownStreamNoDisc << " + ";
        }
        breakdownStreamNoDisc << sym << "(" << rawCost << ")";
        firstNoDisc = false;
        totalNoDiscount += rawCost;
        
        // 2) Discounted breakdown
        long discCost = rawCost;
        if (activeVehicle->isPreferredTerrain(sym)) {
            discCost /= 2;
            // Count this as a preferred terrain cell
            preferredCount++;
        }
        if (!firstDisc) {
            breakdownStreamDisc << " + ";
        }
        breakdownStreamDisc << sym << "(" << discCost << ")";
        firstDisc = false;
        totalDiscount += discCost;
    }
    
    // Build a final combined bill string.
    // NEW: We insert the counters before the existing energy breakdown lines.
    std::ostringstream finalBill;
    finalBill << "Preferred Terrain Count = " << preferredCount << "\n"
              << "Total Terrain Traversed = " << totalTraversed << "\n"
              << "Total Movt Enrg reqd (Generic Veh) = " << breakdownStreamNoDisc.str() 
              << " = " << totalNoDiscount << "\n"
              << "Total Movt Enrg reqd (" << activeVehicle->getVehicleType() << ")  = " 
              << breakdownStreamDisc.str() << " = " << totalDiscount;
    
    DijkstraResult result;
    result.path      = attempt;
    // You can choose which cost to store; here we store the discounted one
    result.cost      = totalDiscount;
    result.breakdown = finalBill.str();
    result.startPos  = sPos;
    result.endPos    = ePos;
    
    allRoutes.push_back(result);
}
        }
    }

    return allRoutes;
}

static vector<GridArea> runDijkstraMinEnergy(const Position& startPos, const Position& endPos)
{
    int rows = (int)maparr.size();
    if (rows == 0) return {};
    int cols = (int)maparr[0].size();

    // Basic bounds checks
    if (startPos.x < 0 || startPos.x >= cols ||
        startPos.y < 0 || startPos.y >= rows ||
        endPos.x   < 0 || endPos.x   >= cols ||
        endPos.y   < 0 || endPos.y   >= rows)
    {
        cerr << "[runDijkstraMinEnergy] Invalid S/E coords.\n";
        return {};
    }

    // Dijkstra data structures
    vector<vector<long>> dist(rows, vector<long>(cols, LONG_MAX));
    vector<vector<pair<int,int>>> prev(rows, vector<pair<int,int>>(cols, {-1, -1}));

    // Min-heap (priority queue) for (x, y, costSoFar)
    priority_queue<Node, vector<Node>, greater<Node>> pq;

    // Initialize starting cell
    dist[startPos.y][startPos.x] = 0;
    pq.push(Node(startPos.x, startPos.y, 0));

    // 4-direction moves
    static const vector<pair<int,int>> directions = {
        {0,-1}, {0,1}, {-1,0}, {1,0}
    };

    while (!pq.empty())
    {
        Node curr = pq.top();
        pq.pop();

        int x = curr.x;
        int y = curr.y;
        long currDist = curr.cost;

        // If we've reached End, we can stop
        if (x == endPos.x && y == endPos.y) {
            break;
        }

        // If outdated cost, skip
        if (currDist > dist[y][x]) {
            continue;
        }

        // Explore neighbors
        for (auto [dx, dy] : directions)
        {
            int nx = x + dx;
            int ny = y + dy;

            // Check boundaries
            if (nx < 0 || ny < 0 || nx >= cols || ny >= rows)
                continue;

            // Check if passable
            char terrainSym = maparr[ny][nx];
            if (!activeVehicle->canTraverseTerrain(terrainSym)) {
                continue;
            }

            // Compute the cost to step onto terrainSym
            // Typically, we do NOT add cost for stepping on 'S' or 'E'.
            // But you can decide how you want to handle that. 
            // For example, let's skip cost if it's 'S' or 'E'.
            long costToMove = 0;
            if (terrainSym != 'S' && terrainSym != 'E')
            {
                long rawCost = getMovementCostForSymbol(terrainSym);
                if (activeVehicle->isPreferredTerrain(terrainSym)) {
                    rawCost /= 2; // discount for preferred
                }
                costToMove = rawCost;
            }

            long newDist = currDist + costToMove;

            if (newDist < dist[ny][nx]) {
                dist[ny][nx] = newDist;
                prev[ny][nx] = {x, y};
                pq.push(Node(nx, ny, newDist));
            }
        }
    }

    // If unreachable, dist[endPos.y][endPos.x] stays LONG_MAX
    if (dist[endPos.y][endPos.x] == LONG_MAX) {
        return {};
    }

    // Reconstruct the route by backtracking from endPos
    vector<GridArea> route;
    int cx = endPos.x;
    int cy = endPos.y;

    while (cx != -1 && cy != -1)
    {
        char sym = maparr[cy][cx];
        route.push_back(GridArea(cx, cy, GridArea::convertCharToTerrainType(sym)));
        auto [px, py] = prev[cy][cx];
        cx = px;
        cy = py;
    }

    reverse(route.begin(), route.end());
    return route;
}

// ----------------------------------------------------------
// computeAllMinEnergyRoutes:
//   * finds the minimum total energy path (with discount logic)
//     from each S to each E
// ----------------------------------------------------------
std::vector<DijkstraResult> computeAllMinEnergyRoutes()
{
    // Collect all S and E from the map
    auto [allStarts, allEnds] = findAllStartAndEndPositions();
    std::vector<DijkstraResult> allRoutes;

    // If no S or E found, just return empty
    if (allStarts.empty() || allEnds.empty()) {
        cerr << "[computeAllMinEnergyRoutes] No S or E found.\n";
        return {};
    }

    // For each start, for each end
    for (auto &sPos : allStarts)
    {
        for (auto &ePos : allEnds)
        {
            // Use runDijkstraMinEnergy to get a path
            vector<GridArea> attempt = runDijkstraMinEnergy(sPos, ePos);

            // PASTE YOUR SNIPPET RIGHT HERE:
            if (!attempt.empty())
            {
                // We'll compute both non-discounted total AND discounted total
                long totalNoDiscount = 0;
                long totalDiscount   = 0;
                
                // We'll store each symbol's cost for display (for each route)
                std::ostringstream breakdownStreamNoDisc;
                std::ostringstream breakdownStreamDisc;
                
                bool firstNoDisc = true;
                bool firstDisc   = true;
                
                // NEW: Counters for preferred terrains and total terrain traversed
                int preferredCount = 0;
                int totalTraversed = 0;
                
                for (auto &cell : attempt)
                {
                    char sym = maparr[cell.getY()][cell.getX()];
                    
                    // Exclude S and E from cost calculations and counting
                    if (sym == 'S' || sym == 'E') {
                        continue;
                    }
                    
                    // Count every traversed terrain cell
                    totalTraversed++;
                    
                    long rawCost = getMovementCostForSymbol(sym);
                    
                    // 1) Non-discounted breakdown
                    if (!firstNoDisc) {
                        breakdownStreamNoDisc << " + ";
                    }
                    breakdownStreamNoDisc << sym << "(" << rawCost << ")";
                    firstNoDisc = false;
                    totalNoDiscount += rawCost;
                    
                    // 2) Discounted breakdown
                    long discCost = rawCost;
                    if (activeVehicle->isPreferredTerrain(sym)) {
                        discCost /= 2;
                        // Count this as a preferred terrain cell
                        preferredCount++;
                    }
                    if (!firstDisc) {
                        breakdownStreamDisc << " + ";
                    }
                    breakdownStreamDisc << sym << "(" << discCost << ")";
                    firstDisc = false;
                    totalDiscount += discCost;
                }
                
                // Build a final combined bill string.
                // NEW: We insert the counters before the existing energy breakdown lines.
                std::ostringstream finalBill;
                finalBill << "Preferred Terrain Count = " << preferredCount << "\n"
                          << "Total Terrain Traversed = " << totalTraversed << "\n"
                          << "Total Movt Enrg reqd (Generic Veh) = " << breakdownStreamNoDisc.str() 
                          << " = " << totalNoDiscount << "\n"
                          << "Total Movt Enrg reqd (" << activeVehicle->getVehicleType() << ")  = " 
                          << breakdownStreamDisc.str() << " = " << totalDiscount;
                
                DijkstraResult result;
                result.path      = attempt;
                // You can choose which cost to store; here we store the discounted one
                result.cost      = totalDiscount;
                result.breakdown = finalBill.str();
                result.startPos  = sPos;
                result.endPos    = ePos;
                
                allRoutes.push_back(result);
            }
        }
    }

    return allRoutes;
}

// ----------------------------------------------------------
// printRouteAsMap: same logic as your older versions
// ----------------------------------------------------------
void printRouteAsMap(const vector<GridArea>& route)
{
    if (maparr.empty()) return;

    int rows = (int)maparr.size();
    int cols = (int)maparr[0].size();
    vector<vector<char>> displayMap(rows, vector<char>(cols, ' '));

    // Mark route cells
    for (auto &cell : route)
    {
        displayMap[cell.getY()][cell.getX()] = maparr[cell.getY()][cell.getX()];
    }

    // Also mark S, E, and '#' on the map
    for (int y = 0; y < rows; ++y)
    {
        for (int x = 0; x < cols; ++x)
        {
            if (maparr[y][x] == 'S' || maparr[y][x] == 'E' || maparr[y][x] == '#')
            {
                displayMap[y][x] = maparr[y][x];
            }
        } 
    }

    // Print column headers with extra spacing
    cout << "     "; // Space for row header
    for (int col = 0; col < cols; ++col)
    {
        cout << setw(3) << col;
    }
    cout << "\n\n";

    // Print each row with its row header
    for (int row = 0; row < rows; ++row)
    {
        cout << setw(3) << row << "  "; // Row header with extra spacing
        for (int col = 0; col < cols; ++col)
        {
            cout << setw(3) << displayMap[row][col];
        }
        cout << "\n";
    }
}