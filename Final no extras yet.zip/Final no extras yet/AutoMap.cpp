#include <iostream>
#include <vector>
#include <string>
#include "Functions.h"
#include "SatComRelay.h"
#include "VehData.h"
#include "GridArea.h"

using namespace std;

extern SatComRelay relay;
extern VehData vehicleData;
extern int vehiclex;
extern int vehicley;
extern std::vector<std::vector<char>> maparr;

void automap(const string& inputFilename, bool isEncrypted, const string& outputFilename)         // NEW PARAMETERS
{
    initTerrainInfo();
    prepareMapForScan();  // ensure there’s a safe buffer before moving

    // ----- Move North as far as possible -----
    while (true)
    {
        // Check that the cell above exists and is not a barrier.
        if (vehicley - 1 < 0 || maparr[vehicley - 1][vehiclex] == '#')
            break;
        autoshield();
        moveN();  // moves the vehicle one cell north (using maparr[y][x])
        prepareMapForScan();
        scanall();
    }

    // ----- Move West as far as possible -----
    while (true)
    {
        if (vehiclex - 1 < 0 || maparr[vehicley][vehiclex - 1] == '#')
            break;
        autoshield();
        moveW();  // moves one cell west
        prepareMapForScan();
        scanall();
    }

    // ----- Lawn Mower Sweep (Horizontal zigzag then move down) -----
    bool movingRight = true;
    while (true)
    {
        // Horizontal sweep along current row.
        while (true)
        {
            autoshield();
            prepareMapForScan();
            scanall();

            int nextX = vehiclex + (movingRight ? 1 : -1);
            int currentY = vehicley;
            // Break out if next cell is out of bounds or impassable.
            if (nextX < 0 || nextX >= width || maparr[currentY][nextX] == '#')
                break;
            

            // Move East or West depending on direction.
            if (movingRight)
                moveE();
            else
                moveW();

        }
        // Try to move one row down.
        int belowY = vehicley + 1;
        if (belowY >= height || maparr[belowY][vehiclex] == '#')
            break;
        
        autoshield();
        moveS();  // move one cell down
        prepareMapForScan();
        scanall();
        
        // Reverse horizontal direction for the next row.
        movingRight = !movingRight;
    }

    // Finally, call autoPilotDate to finish processing and output the final map report.
    autoPilotDate(inputFilename, isEncrypted, outputFilename);
}

