#include <iostream>
#include <string>   

#include "Functions.h"
#include "SatComRelay.h"
#include "VehData.h"
#include "GridArea.h"

using namespace std;

extern SatComRelay relay;

void init(const string &inputFilename, bool fileNeedsDecryption, bool randomizeStartPos, int missionType)
{
    VehData vdt = relay.initializeVehicle(inputFilename, fileNeedsDecryption, randomizeStartPos, missionType);
}