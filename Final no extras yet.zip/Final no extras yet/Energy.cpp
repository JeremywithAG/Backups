#include <iostream>

#include "SatComRelay.h"
#include "VehData.h"
#include "Functions.h"  
#include "GridArea.h"

using namespace std;


extern SatComRelay relay;
extern VehData vehicleData;

void autoshield()
 {
    const int threshold = 5000;
    int currentShield = vehicleData.getCurrentShieldEnergy();
    if (currentShield < threshold)
     {
         int needed = threshold - currentShield;
         vehicleData = relay.allocateEnergyToShield(needed);
    }
}
