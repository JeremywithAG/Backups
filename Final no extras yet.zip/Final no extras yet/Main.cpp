#include <iostream>
#include <string>
#include <ctime>

#include "SatComRelay.h"
#include "Functions.h"
#include "VehData.h"
#include "GridArea.h"
#include "Vehicle.h"

using namespace std;

Vehicle* activeVehicle = nullptr;
SatComRelay relay;
VehData vehicleData;

int main()
{
    string inputFilename = "Scenario06.dat";
    bool isEncrypted = true;
    bool randomizeStartPosition = false;
    string outputFilename = "map-rpt.txt";

    string inputMapFilename = "map-rpt.txt";
    string outputRouteFilename = "route-rpt.txt";
    string routeCriteria = "shortest distance from Start to End locations";
    string vehicleType = "ShieldHero";

    int choice;
    do 
    {
        displayMainMenu(1, "Alexandre Cotton",0);
        choice = getValidatedChoice(1, 5);
        
        mapinit();

        switch (choice) 
        {
            case 1:
            {
                configureAutopilotSettings(inputFilename, isEncrypted, outputFilename);
                break;
            }
            case 2:
            {
                configureSimulatorSettings(inputMapFilename, outputRouteFilename, routeCriteria, vehicleType);
                break;
            }
            case 3:
            {
                int missionType = 999999;
                init(inputFilename, isEncrypted, randomizeStartPosition, missionType);
                automap(inputFilename, isEncrypted, outputFilename);  
                break;
            }
            case 4:
            {
                cout << endl;
                cout << "Input map details filename = "<< inputMapFilename << endl;
                cout << "OUTPUT route report        = "<< outputRouteFilename << endl;
                cout << "Ideal Route Criteria       = "<< routeCriteria << endl;
                cout << "Vehicle Type               = "<< vehicleType << endl;
                
                cout << endl;

                time_t simStart = time(nullptr);
                string startTimeStr = getCurrentTime();
                cout << "Start datetime stamp       = " << startTimeStr << endl;

                time_t simEnd = time(nullptr);
                string endTimeStr = getCurrentTime();
                cout << "End datetime stamp         = " << endTimeStr << endl;

                cout << endl;

                int duration = static_cast<int>(difftime(simEnd, simStart));
                int hours   = duration / 3600;
                int minutes = (duration % 3600) / 60;
                int seconds = duration % 60;

                cout << "Total Simulation Duration  = " << hours << " hr " << minutes << " min " 
                << seconds << " sec" << endl;
                
                cout << endl;

                if (activeVehicle != nullptr) 
                {
                    delete activeVehicle;
                    activeVehicle = nullptr;
                }

                if (vehicleType == "HighLander") 
                {
                    activeVehicle = new HighLander();
                }
                else if (vehicleType == "DragonFly") 
                {
                    activeVehicle = new DragonFly();
                }
                else if (vehicleType == "ShieldHero") 
                {
                    activeVehicle = new ShieldHero();
                }
                else 
                {
                    activeVehicle = new ShieldHero();
                }
                initializeLogging(outputRouteFilename);
                maparr = parseMapFromFile(inputMapFilename);
                vector<DijkstraResult> routes;
                if (routeCriteria == "shortest distance from Start to End locations")
                {
                    routes = computeAllDijkstraRoutes();
                }
                else if (routeCriteria == "minimized total energy expenditure")
                {
                    routes = computeAllMinEnergyRoutes();
                }
                else
                {
                    // fallback or error
                    cerr << "Invalid route criteria, defaulting to shortest distance...\n";
                    routes = computeAllDijkstraRoutes();
                }
            
                if (routes.empty()) {
                    cout << "No routes found from any S to E." << endl;
                } else {
                    int i = 1;
                    for (auto &r : routes)
                    {
                        
                        cout << "Route #" << i++ << " - From " << "[" << r.startPos.x << "," << r.startPos.y << "]" 
                        << " to ["   << r.endPos.x   << "," << r.endPos.y   << "]\n";
                        
                        cout << "\n";

                        cout << "Sequence: ";
                        bool first = true;
                        for (auto &cell : r.path)
                        {
                            // Print a comma and space ONLY if it's not the first element
                            if (!first) {
                                cout << ", ";
                            } else {
                                first = false;
                            }
                        
                            // Now print the coordinate
                            cout << "[" << cell.getX() << "," << cell.getY() << "]";
                        }
                        cout << "\n";
                        cout << "\n";

                        // Print the cost breakdown
                        cout << r.breakdown << "\n";
                        cout << "\n";
                        printRouteAsMap(r.path);
                
                        cout << "\n"; // blank line
                    }
                }
                restoreLogging();
                break;
            }
            case 5:
            {
                cout << "Exiting program..." << endl;
                break;
            }
            default:
            {
                cout << "Invalid choice! Please enter a number between 1-5." << endl;
                break;
            }
        }
    } while (choice != 5);

    if (activeVehicle != nullptr) 
    {
        delete activeVehicle;
        activeVehicle = nullptr;
    }
    return 0;
}
