#include "Functions.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <cctype>      // for isspace
#include <algorithm>  // for std::remove

using namespace std;

vector<vector<char>> parseMapFromFile(const string& filename)
{
    ifstream infile(filename);
    vector<vector<char>> mapData;

    if (!infile.is_open())
    {
        cerr << "Error opening file: " << filename << endl;
        return mapData;
    }

    string line;
    while (getline(infile, line))
    {
        // 1) Remove any '\r' characters (common in Windows line endings)
        line.erase(remove(line.begin(), line.end(), '\r'), line.end());

        // 2) Strip trailing whitespace
        while (!line.empty() && isspace(static_cast<unsigned char>(line.back())))
        {
            line.pop_back();
        }

        // 3) Convert '.' to an actual space if the file uses '.' as "blank"
        for (char &c : line)
        {
            if (c == '.')
                c = ' ';
        }

        // 4) Store the entire line as a row of chars
        vector<char> row(line.begin(), line.end());
        mapData.push_back(row);
    }

    infile.close();

    // 5) Determine the maximum width among all rows
    size_t maxWidth = 0;
    for (auto &r : mapData)
    {
        if (r.size() > maxWidth)
            maxWidth = r.size();
    }

    // 6) Pad any shorter rows with spaces so every row matches maxWidth
    //    (This ensures a consistent, rectangular map.)
    for (auto &r : mapData)
    {
        while (r.size() < maxWidth)
        {
            r.push_back(' ');
        }
    }

    // Debug-print the final rectangular map so you can confirm row/column counts
   // cout << "\n[DEBUG] Map data parsed from '" << filename << "':\n";
  //  for (int y = 0; y < (int)mapData.size(); ++y)
   // {
       // cout << "Row " << y << " (" << mapData[y].size() << " cols): ";
       // for (char c : mapData[y])
        //{
          //  cout << c;  
            // Note: printing a raw space won't "show," but it ensures alignment.
        //}
      //  cout << "\n";
   // }
   // cout << "[END DEBUG OUTPUT]\n\n";

    return mapData;
}
