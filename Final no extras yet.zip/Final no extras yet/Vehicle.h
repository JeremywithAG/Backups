#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>
#include <vector>
#include "GridArea.h"

using namespace std;

typedef vector<GridArea> VecGridAreaType;

class Vehicle {
protected:
    // Existing fields...
    VecGridAreaType mapData;
    string vehicleID;
    string vehicleType;
    long initialEnergy;
    long currentEnergy;
    long currentShieldEnergy;
    long totalEnergyUsed;
    long totalShieldEnergyUsed;

    // --- NEW: Tracking counters ---
    int countPreferredCells;  // how many times we stepped on the vehicle's "preferred" terrain
    int countBarrierCells;    // how many times we stepped on '#'
    int countStartCells;      // how many times we stepped on 'S'
    int countEndCells;        // how many times we stepped on 'E'

public:
    // Constructors
    Vehicle();
    Vehicle(const string& id, const string& type, long initialEnergy, const VecGridAreaType& _entireMap);
    virtual ~Vehicle() = default;

    // Map data
    void setMapData(const VecGridAreaType& _entireMap);
    VecGridAreaType getMapData() const;

    // Accessors
    string getVehicleID() const;
    string getVehicleType() const;
    long getInitialEnergy() const;
    long getCurrentEnergy() const;
    long getCurrentShieldEnergy() const;
    long getTotalEnergyUsed() const;
    long getTotalShieldEnergyUsed() const;

    // Mutators
    void setVehicleID(const string& id);
    void setVehicleType(const string& type);
    void setInitialEnergy(long energy);
    void setCurrentEnergy(long energy);
    void setCurrentShieldEnergy(long energy);
    void setTotalEnergyUsed(long energy);
    void setTotalShieldEnergyUsed(long energy);

    // Utilities
    virtual void allocateShieldEnergy(long amount);
    virtual void useEnergy(long amount);
    virtual void useShieldEnergy(long amount);

    // --- NEW: a function to track visited terrain ---
    void trackCellVisited(char terrainSymbol);

    // --- NEW: a function to display the tracking results ---
    void printTrackingStats() const;

    // Terrain handling
    virtual bool canTraverseTerrain(char terrainSymbol) const;
    virtual bool isPreferredTerrain(char terrainSymbol) const = 0;

    // Core functionality
    virtual VecGridAreaType computeRoute(const vector<vector<char>>& map) const = 0;
    virtual vector<VecGridAreaType> computeAllIdealRoutes() const = 0;
    virtual void displayRouteReport() const = 0;
    virtual void printRouteReport(const string& outputFilename) const = 0;
};

// ========== Derived Classes ==========

class HighLander : public Vehicle {
public:
    HighLander();
    HighLander(const VecGridAreaType& _entireMap);

    bool canTraverseTerrain(char terrainSymbol) const override;
    bool isPreferredTerrain(char terrainSymbol) const override;

    VecGridAreaType computeRoute(const vector<vector<char>>& map) const override;
    vector<VecGridAreaType> computeAllIdealRoutes() const override;
    void displayRouteReport() const override;
    void printRouteReport(const string& outputFilename) const override;
};

class DragonFly : public Vehicle {
public:
    DragonFly();
    DragonFly(const VecGridAreaType& _entireMap);

    bool canTraverseTerrain(char terrainSymbol) const override;
    bool isPreferredTerrain(char terrainSymbol) const override;

    VecGridAreaType computeRoute(const vector<vector<char>>& map) const override;
    vector<VecGridAreaType> computeAllIdealRoutes() const override;
    void displayRouteReport() const override;
    void printRouteReport(const string& outputFilename) const override;
};

class ShieldHero : public Vehicle {
public:
    ShieldHero();
    ShieldHero(const VecGridAreaType& _entireMap);

    bool canTraverseTerrain(char terrainSymbol) const override;
    bool isPreferredTerrain(char terrainSymbol) const override;

    VecGridAreaType computeRoute(const vector<vector<char>>& map) const override;
    vector<VecGridAreaType> computeAllIdealRoutes() const override;
    void displayRouteReport() const override;
    void printRouteReport(const string& outputFilename) const override;
};

#endif
