#include "Vehicle.h"
#include <iostream>
#include <fstream>

using namespace std;

// ====== Base Vehicle Implementation ======

Vehicle::Vehicle()
    : vehicleID("N.A."), vehicleType("Unknown"), initialEnergy(0),
      currentEnergy(0), currentShieldEnergy(0),
      totalEnergyUsed(0), totalShieldEnergyUsed(0),
      // Initialize counters to 0
      countPreferredCells(0), countBarrierCells(0),
      countStartCells(0), countEndCells(0)
{
}

Vehicle::Vehicle(const string& id, const string& type, long energy, const VecGridAreaType& _entireMap)
    : vehicleID(id), vehicleType(type),
      initialEnergy(energy), currentEnergy(energy), currentShieldEnergy(0),
      totalEnergyUsed(0), totalShieldEnergyUsed(0),
      mapData(_entireMap),
      // Initialize counters to 0
      countPreferredCells(0), countBarrierCells(0),
      countStartCells(0), countEndCells(0)
{
}

void Vehicle::setMapData(const VecGridAreaType& _entireMap) {
    mapData = _entireMap;
}

VecGridAreaType Vehicle::getMapData() const {
    return mapData;
}

string Vehicle::getVehicleID() const { return vehicleID; }
string Vehicle::getVehicleType() const { return vehicleType; }
long Vehicle::getInitialEnergy() const { return initialEnergy; }
long Vehicle::getCurrentEnergy() const { return currentEnergy; }
long Vehicle::getCurrentShieldEnergy() const { return currentShieldEnergy; }
long Vehicle::getTotalEnergyUsed() const { return totalEnergyUsed; }
long Vehicle::getTotalShieldEnergyUsed() const { return totalShieldEnergyUsed; }

void Vehicle::setVehicleID(const string& id) { vehicleID = id; }
void Vehicle::setVehicleType(const string& type) { vehicleType = type; }
void Vehicle::setInitialEnergy(long energy) { initialEnergy = energy; }
void Vehicle::setCurrentEnergy(long energy) { currentEnergy = energy; }
void Vehicle::setCurrentShieldEnergy(long energy) { currentShieldEnergy = energy; }
void Vehicle::setTotalEnergyUsed(long energy) { totalEnergyUsed = energy; }
void Vehicle::setTotalShieldEnergyUsed(long energy) { totalShieldEnergyUsed = energy; }

void Vehicle::allocateShieldEnergy(long amount) {
    currentShieldEnergy += amount;
    totalShieldEnergyUsed += amount;
}

void Vehicle::useEnergy(long amount) {
    currentEnergy -= amount;
    totalEnergyUsed += amount;
}

void Vehicle::useShieldEnergy(long amount) {
    currentShieldEnergy -= amount;
    totalShieldEnergyUsed += amount;
}

// -----------------------------------------------------------------------------
// trackCellVisited: increments counters if terrain is S, E, #, or preferred
// -----------------------------------------------------------------------------
void Vehicle::trackCellVisited(char terrainSymbol)
{
    if (terrainSymbol == '#')
    {
        countBarrierCells++;
    }
    else if (terrainSymbol == 'S')
    {
        countStartCells++;
    }
    else if (terrainSymbol == 'E')
    {
        countEndCells++;
    }
    else if (isPreferredTerrain(terrainSymbol))
    {
        countPreferredCells++;
    }
    // If you’d like to track other terrains, you can add logic here
}

// -----------------------------------------------------------------------------
// printTrackingStats: prints counters plus any other stats you like
// -----------------------------------------------------------------------------
void Vehicle::printTrackingStats() const
{
    cout << "\n[Vehicle Stats: " << vehicleID << " (" << vehicleType << ")]\n";
    cout << "  Total Energy Used: " << totalEnergyUsed << "\n";
    cout << "  Shield Energy Used: " << totalShieldEnergyUsed << "\n";
    cout << "  Preferred terrain visited: " << countPreferredCells << "\n";
    cout << "  Barrier ('#') visited:    " << countBarrierCells << "\n";
    cout << "  Start ('S') visited:      " << countStartCells << "\n";
    cout << "  End   ('E') visited:      " << countEndCells << "\n";
}

// -----------------------------------------------------------------------------
// The default canTraverseTerrain says "anything but '#' is passable."
// Derived classes override it for specialized logic
// -----------------------------------------------------------------------------
bool Vehicle::canTraverseTerrain(char terrainSymbol) const {
    return terrainSymbol != '#';
}

// ====== HighLander ======
HighLander::HighLander() : Vehicle("HL001", "HighLander", 100000, {}) {}
HighLander::HighLander(const VecGridAreaType& _entireMap)
    : Vehicle("HL001", "HighLander", 100000, _entireMap) {}

    bool HighLander::canTraverseTerrain(char terrainSymbol) const {
        // Allow all terrain except barrier '#'
        return (terrainSymbol != '#');
    }
    
    bool HighLander::isPreferredTerrain(char terrainSymbol) const {
        // 50% discount on 'h' or 'M'
        return (terrainSymbol == 'h' || terrainSymbol == 'M');
    }

VecGridAreaType HighLander::computeRoute(const vector<vector<char>>& map) const {
    // placeholder
    return {};
}

vector<VecGridAreaType> HighLander::computeAllIdealRoutes() const {
    return {};
}

void HighLander::displayRouteReport() const {
    cout << "[HighLander] Display Route Report - TODO\n";
}

void HighLander::printRouteReport(const string& outputFilename) const {
    ofstream out(outputFilename);
    if (out) {
        out << "[HighLander] Route Report - TODO\n";
        out.close();
    }
}

// ====== DragonFly ======
DragonFly::DragonFly() : Vehicle("DF001", "DragonFly", 100000, {}) {}
DragonFly::DragonFly(const VecGridAreaType& _entireMap)
    : Vehicle("DF001", "DragonFly", 100000, _entireMap) {}

    bool DragonFly::canTraverseTerrain(char terrainSymbol) const {
        // Allow all terrain except barrier '#'
        return (terrainSymbol != '#');
    }
    
    bool DragonFly::isPreferredTerrain(char terrainSymbol) const {
        // 50% discount on 'w' or '~'
        return (terrainSymbol == 'w' || terrainSymbol == '~');
    }

VecGridAreaType DragonFly::computeRoute(const vector<vector<char>>& map) const {
    // placeholder
    return {};
}

vector<VecGridAreaType> DragonFly::computeAllIdealRoutes() const {
    return {};
}

void DragonFly::displayRouteReport() const {
    cout << "[DragonFly] Display Route Report - TODO\n";
}

void DragonFly::printRouteReport(const string& outputFilename) const {
    ofstream out(outputFilename);
    if (out) {
        out << "[DragonFly] Route Report - TODO\n";
        out.close();
    }
}

// ====== ShieldHero ======
ShieldHero::ShieldHero() : Vehicle("SH001", "ShieldHero", 100000, {}) {}
ShieldHero::ShieldHero(const VecGridAreaType& _entireMap)
    : Vehicle("SH001", "ShieldHero", 100000, _entireMap) {}

    bool ShieldHero::canTraverseTerrain(char terrainSymbol) const {
        // Allow all terrain except barrier '#'
        return (terrainSymbol != '#');
    }
    
    bool ShieldHero::isPreferredTerrain(char terrainSymbol) const {
        // 50% discount on 'X'
        return (terrainSymbol == 'X');
    }

VecGridAreaType ShieldHero::computeRoute(const vector<vector<char>>& map) const {
    // placeholder
    return {};
}

vector<VecGridAreaType> ShieldHero::computeAllIdealRoutes() const {
    return {};
}

void ShieldHero::displayRouteReport() const {
    cout << "[ShieldHero] Display Route Report - TODO\n";
}

void ShieldHero::printRouteReport(const string& outputFilename) const {
    ofstream out(outputFilename);
    if (out) {
        out << "[ShieldHero] Route Report - TODO\n";
        out.close();
    }
}
