#include "Functions.h"
#include <limits>
#include <iostream>
#include <cctype> 

using namespace std;

int getValidatedChoice(int min, int max, int depth)
{
    string input;
    string indent(depth, '\t'); // Use tab (`\t`) instead of spaces
    int choice;

    while (true)
    {
        cout << indent << "Please enter your choice (" << min << "-" << max << "): ";
        getline(cin, input);

        // Check if input is empty (Enter key alone)
        if (input.empty())
        {
            cout << indent << "Invalid Input!\n";
            continue;
        }

        // Validate input contains only digits
        bool isValid = true;
        for (char c : input)
        {
            if (!isdigit(c))
            {
                isValid = false;
                break;
            }
        }

        if (!isValid)
        {
            cout << indent << "Invalid Input!\n";
            continue;
        }

        // Convert input to integer safely
        try
        {
            choice = stoi(input);

            // Ensure the number is within the valid range
            if (choice < min || choice > max)
            {
                cout << indent << "Invalid Input!\n";
                continue;
            }

            break; // Valid input, exit loop
        }
        catch (...)
        {
            cout << indent << "Invalid Input!\n";
        }
    }

    return choice;
}

char getValidatedCharChoice(const string& validChoices, int depth)
{
    string input;
    string indent(depth, '\t'); // Use tab (`\t`) instead of spaces
	char minChar = validChoices.front();  // First valid choice (e.g., 'a')
    char maxChar = validChoices.back();   // Last valid choice (e.g., 'e')
	
    while (true)
    {
        cout << indent << "Please enter your choice (" << minChar << " - " << maxChar << "): ";
        getline(cin, input);

        // Check if input is empty
        if (input.empty())
        {
            cout << indent << "Invalid Input!\n";
            continue;
        }

        // Ensure input is exactly one character
        if (input.length() != 1)
        {
            cout << indent << "Invalid Input!\n";
            continue;
        }

        // Convert to lowercase for case insensitivity (optional)
        char choice = tolower(input[0]);

        // Check if input is within valid choices
        if (validChoices.find(choice) != string::npos)
        {
            return choice;  // Valid choice
        }
        else
        {
            cout << indent << "Invalid Input!\n";
        }
    }
}

std::string getValidatedFileName(const std::string &extension, const std::string &prompt, int depth)
{
    string input;
    string indent(depth, '\t');
    while (true)
    {
        cout << indent << prompt; 
        getline(cin, input);

        // Trim the input (remove spaces from beginning and end)
        size_t start = input.find_first_not_of(" \t");
        size_t end = input.find_last_not_of(" \t");
        if (start == string::npos || end == string::npos)
            input = "";
        else
            input = input.substr(start, end - start + 1);

        if (input.empty())
        {
            cout << indent << "Invalid input!\n";
            continue;
        }
        if (input.length() <= extension.length())
        {
            cout << indent << "Invalid input!\n";
            continue;
        }
        if (input.substr(input.size() - extension.size()) != extension)
        {
            cout << indent << "Invalid input!\n";
            continue;
        }
        // Check that there is at least one non-space character before the extension.
        string namePart = input.substr(0, input.size() - extension.size());
        bool hasNonSpace = false;
        for (char c : namePart)
        {
            if (!isspace(c))
            {
                hasNonSpace = true;
                break;
            }
        }
        if (!hasNonSpace)
        {
            cout << indent << "Invalid input!\n";
            continue;
        }
        return input;
    }
}
    