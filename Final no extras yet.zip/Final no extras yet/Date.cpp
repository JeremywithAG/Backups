#include <iostream>
#include <thread>
#include <chrono>
#include <cctype>
#include <limits>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <string>
#include <fstream>      // <-- added
#include <streambuf>    // <-- added

#include "SatComRelay.h"
#include "Functions.h"
#include "GridArea.h"
#include "VehData.h"

extern int vehiclex;                        
extern int vehicley;
extern std::vector<std::vector<char>> maparr;

string getCurrentTime() 
{
    time_t now = time(nullptr);
    tm* localTime = localtime(&now);
    std::ostringstream oss;
    oss << std::setfill('0') << std::setw(2) << localTime->tm_mday << "/"
        << std::setw(2) << (localTime->tm_mon + 1) << "/"
        << (localTime->tm_year % 100) << " "
        << std::setw(2) << localTime->tm_hour << ":"
        << std::setw(2) << localTime->tm_min << ":"
        << std::setw(2) << localTime->tm_sec;
    return oss.str();
}

void autoPilotDate(const std::string& inputFilename, bool isEncrypted, const std::string& outputFilename)
{
    using namespace std;

    cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nPlease enter your choice: 3\n";
    cout << "[ Start Autopilot Mapping ]\n\n";
    cout << "INPUT scenario file name    = \033[32m" << inputFilename << "\033[0m\n";
    cout << "INPUT scenario file encrypted = \033[32m" 
         << (isEncrypted ? "Y" : "N") << "\033[0m\n";
    cout << "OUTPUT map report filename  = \033[32m" 
         << outputFilename << "\033[0m\n\n";

    // Ask if the user wants to display the report AFTER processing is complete
	cout << "When mapping ends, do you wish to display the map report on Ubuntu terminal? (Y/N): "<< endl;
    char displayChoice = getValidatedCharChoice("YynN"); // Force user to pick y or n
    displayChoice = toupper(displayChoice);
    bool displayReport = (displayChoice == 'Y');

    // 2) Prompt user to confirm "BEGIN NOW? (Y) :"
    cout << "\nBEGIN NOW? (Y) : "<< endl;
    char beginChoice = getValidatedCharChoice("YynN");
	
    // Start mapping process
    string startTime = getCurrentTime();
    time_t start = time(nullptr);
    cout << "\nAutopilot Mapping STARTED!   Start datetime stamp = " << startTime << "\n";
    cout << "\n          MAPPING IN PROGRESS … PLEASE DO NOT END PROGRAM!\n";

    this_thread::sleep_for(chrono::seconds(5)); // Simulated delay

    // Mapping completed
    string endTime = getCurrentTime();
    time_t end = time(nullptr);
    cout << "\nAutopilot Mapping ENDED!     End datetime stamp = " << endTime << "\n";

    // Calculate mapping duration
    int duration = static_cast<int>(difftime(end, start));
    int hours = duration / 3600;
    int minutes = (duration % 3600) / 60;
    int seconds = duration % 60;

    cout << "\nTotal Mapping Duration: "
         << setw(2) << setfill('0') << hours << " hr "
         << setw(2) << minutes << " min "
         << setw(2) << seconds << " sec\n";

    //
    // 1) Always write the map (and terrain info) to the specified file
    //
    {
        writeRawMapToFile(outputFilename);
    }

    // 2) Check if user wants to see the map on-screen
    if (displayReport)
    {
        // We also show them the final info on the terminal
        cout << "\nMap report saved to: \033[32m" << outputFilename << "\033[0m\n ";
        cout << "\nDisplaying contents of \033[32m" 
             << outputFilename << "\033[0m on \033[4mUbuntu Terminal\033[0m:\n";
        cout << "\nINPUT scenario file name    = \033[32m" 
             << inputFilename << "\033[0m\n";
        cout << "INPUT scenario file encrypted = \033[32m" 
             << (isEncrypted ? "Y" : "N") << "\033[0m\n";
        cout << "OUTPUT map report filename  = \033[32m" 
             << outputFilename << "\033[0m\n\n";
        cout << "Start datetime stamp = " << startTime << "\n";
        cout << "End datetime stamp   = " << endTime << "\n";
        cout << "\nTotal Mapping Duration: "
             << setw(2) << setfill('0') << hours << " hr "
             << setw(2) << minutes << " min "
             << setw(2) << seconds << " sec\n";

        // Now print map to the terminal as well
        mapprint();
        cout << std::setfill(' ');
        printTerrainInfo();

        cout << "\nPress <Enter> to go back to main menu …";
        while (true)
        {
            // read a line
            string input;
            getline(cin, input);
            // if it's empty, break
            if (input.empty())
                break;
            // otherwise, instruct user to press only Enter
            cout << "Please press Enter ONLY: ";
        }
        cout << "\nGoing back to main menu …\n";
    }
    else
    {
        // If user chooses 'N', no screen display.
        cout << "\nNoted, Map report \033[31mWILL NOT\033[0m be displayed on the terminal.\n";
    }
}
