#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <string>
#include <vector>
#include <climits>

#include "SatComRelay.h"
#include "GridArea.h"
#include "Vehicle.h"

using namespace std;

extern int width;
extern int height;

extern int vehiclex;
extern int vehicley;

extern Vehicle* activeVehicle;

extern std::vector<std::vector<char>> maparr;


class SatComRelay;

struct Position 
{
    int x, y;

    Position() : x(0), y(0) {}
    
    Position(int _x, int _y);
};

struct DijkstraResult 
{
    std::vector<GridArea> path;
    long cost;
    std::string breakdown;
    // Optional extra fields:
    Position startPos;
    Position endPos;
};

//menus
void displayMainMenu(int teamNumber, const string& teamLeaderName, int depth = 0);
void configureAutopilotSettings(string& inputFilename, bool& isEncrypted, string& outputFilename, int depth = 0);
void configureSimulatorSettings(string& inputMapFilename, string& outputRouteFilename, string& routeCriteria, string& vehicleType, int depth = 0);

//date
string getCurrentTime();
void autoPilotDate(const std::string& inputFilename, bool isEncrypted, const std::string& outputFilename);

//init
void init(const string &inputFilename, bool fileNeedsDecryption, bool randomizeStartPos, int missionType);

//map
void mapinit();
void mapprint();
void prepareMapForScan();
void checkAndExpand();
void writeRawMapToFile(const std::string &filename);

//scan
void scanall();

//movement
void moveN();
void moveS();
void moveE();
void moveW();

//energy
void autoshield();

//automap
void automap(const string& inputFilename, bool isEncrypted, const string& outputFilename);

// Custom stream buffer class for dual output (console and file)
class DualStreamBuf : public streambuf 
{
    public:
        DualStreamBuf(streambuf* original, ofstream& logFile);
    protected:
        virtual int overflow(int c) override;
        virtual streamsize xsputn(const char* s, streamsize n) override;
    private:
        streambuf* originalBuffer;
        ofstream& file;
};

// Logging function declarations
void initializeLogging(const string &outputFilename);
string getLoggedInput(const string &prompt);
void restoreLogging();

//terrainINFO
struct TerrainInfo
{
        char symbol;
        bool discovered;
        std::string movtEnergy;
        std::string shieldEnergy;
};

extern TerrainInfo terrainInfo[];
void initTerrainInfo();
void updateTerrainEnergyReq(char terrainSymbol, long movtUsed, long shieldUsed);
void printTerrainInfo();
long getMovementCostForSymbol(char terrainSymbol);

//validation
int getValidatedChoice(int min, int max, int depth = 0);
char getValidatedCharChoice(const string& validChoices, int depth = 0);
string getValidatedFileName(const string &extension, const string &prompt, int depth = 0);

//parse map
vector<vector<char>> parseMapFromFile(const string& filename);

//maputil
std::pair<std::vector<Position>, std::vector<Position>> findAllStartAndEndPositions();
std::pair<Position, Position> findStartAndEndPositions();

//findpath
void printRouteAsMap(const vector<GridArea>& route);
std::vector<DijkstraResult> computeAllDijkstraRoutes();
std::vector<DijkstraResult> computeAllMinEnergyRoutes();

inline Position::Position(int _x, int _y) : x(_x), y(_y) {}


#endif