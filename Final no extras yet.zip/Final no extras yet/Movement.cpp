#include <iostream>
#include "SatComRelay.h"
#include "Functions.h"
#include "VehData.h"
#include "GridArea.h"

using namespace std;

extern SatComRelay relay;
extern VehData vehicleData;

extern int vehiclex;
extern int vehicley;

extern std::vector<std::vector<char>> maparr;

void moveN() 
{
    checkAndExpand();
    char scanresult = relay.scanNorth(vehicleData);
    char symbol = scanresult;
	long oldEnergy = vehicleData.getCurrentEnergy();
    long oldShield = vehicleData.getCurrentShieldEnergy();
    vehicleData = relay.moveUpNorth();
	long newEnergy = vehicleData.getCurrentEnergy();
    long newShield = vehicleData.getCurrentShieldEnergy();
    long usedMovt = oldEnergy - newEnergy;
    long usedShld = oldShield - newShield;
    updateTerrainEnergyReq(symbol, usedMovt, usedShld);
    if ((scanresult == '#')) 
    {
        return;
    } 
    else 
    {
        vehicley--;
    }
}

void moveS() 
{
    checkAndExpand();
    char scanresult = relay.scanSouth(vehicleData);
    char symbol = scanresult;
	long oldEnergy = vehicleData.getCurrentEnergy();
    long oldShield = vehicleData.getCurrentShieldEnergy();
    vehicleData = relay.moveDownSouth();
	long newEnergy = vehicleData.getCurrentEnergy();
    long newShield = vehicleData.getCurrentShieldEnergy();
    long usedMovt = oldEnergy - newEnergy;
    long usedShld = oldShield - newShield;
    updateTerrainEnergyReq(symbol, usedMovt, usedShld);
    if ((scanresult == '#')) 
    {
        return;
    } 
    else 
    {
        vehicley++;
    }
}

void moveE() 
{
    checkAndExpand();
    char scanresult = relay.scanEast(vehicleData);
    char symbol = scanresult;
	long oldEnergy = vehicleData.getCurrentEnergy();
    long oldShield = vehicleData.getCurrentShieldEnergy();
    vehicleData = relay.moveRightEast();
	long newEnergy = vehicleData.getCurrentEnergy();
    long newShield = vehicleData.getCurrentShieldEnergy();
    long usedMovt = oldEnergy - newEnergy;
    long usedShld = oldShield - newShield;
    updateTerrainEnergyReq(symbol, usedMovt, usedShld);
    if ((scanresult == '#')) 
    {
        return;
    } 
    else 
    {
        vehiclex++;
    }
}

void moveW() 
{
    checkAndExpand();
    char scanresult = relay.scanWest(vehicleData);
    char symbol = scanresult;
	long oldEnergy = vehicleData.getCurrentEnergy();
    long oldShield = vehicleData.getCurrentShieldEnergy();
    vehicleData = relay.moveLeftWest();
	long newEnergy = vehicleData.getCurrentEnergy();
    long newShield = vehicleData.getCurrentShieldEnergy();
    long usedMovt = oldEnergy - newEnergy;
    long usedShld = oldShield - newShield;
    updateTerrainEnergyReq(symbol, usedMovt, usedShld);
    if ((scanresult == '#')) 
    {
        return;
    } 
    else 
    {
        vehiclex--;
    }
}

