#include "Functions.h"
#include <vector>
#include <iostream>

using namespace std;

// Global 2D map array (already declared externally)
extern vector<vector<char>> maparr;

// ---------------------------------------------------------------------
// 1) Original single-S/single-E function (unchanged)
//    This remains for backward compatibility in case you still need it.
// ---------------------------------------------------------------------
pair<Position, Position> findStartAndEndPositions()
{
    Position start(-1, -1);
    Position end(-1, -1);

    for (int y = 0; y < (int)maparr.size(); ++y)
    {
        for (int x = 0; x < (int)maparr[y].size(); ++x)
        {
            if (maparr[y][x] == 'S')
            {
                start = Position(x, y);
            }
            else if (maparr[y][x] == 'E')
            {
                end = Position(x, y);
            }
        }
    }

    if (start.x == -1 || end.x == -1)
    {
        cerr << "Error: At least one single-S or single-E not found in maparr.\n";
    }

    return {start, end};
}

// ---------------------------------------------------------------------
// 2) New function: find **all** S and **all** E
//    Returns a pair: { vector_of_all_S_positions, vector_of_all_E_positions }
// ---------------------------------------------------------------------
pair<vector<Position>, vector<Position>> findAllStartAndEndPositions()
{
    vector<Position> starts;
    vector<Position> ends;

    for (int y = 0; y < (int)maparr.size(); ++y)
    {
        for (int x = 0; x < (int)maparr[y].size(); ++x)
        {
            if (maparr[y][x] == 'S')
            {
                starts.push_back(Position(x, y));
            }
            else if (maparr[y][x] == 'E')
            {
                ends.push_back(Position(x, y));
            }
        }
    }

    if (starts.empty() || ends.empty())
    {
        cerr << "Warning: No 'S' or no 'E' found in maparr.\n";
    }

    return {starts, ends};
}
