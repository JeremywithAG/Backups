#include <iostream>
#include <fstream>
#include <vector>

#include "Functions.h"
#include "SatComRelay.h"
#include "VehData.h"
#include "GridArea.h"

using namespace std;

// Define the variables here once only\int width = 4;

int width = 4;
int height = 4;

int vehiclex = width / 2;  // Start in center
int vehicley = height / 2;

std::vector<std::vector<char>> maparr;

void mapinit()
{
    maparr = std::vector<std::vector<char>>(width, std::vector<char>(height, ' '));
}

void checkAndExpand() 
{
    // Expand left if we are at x <= 1 (so scanning west or NW/SW won’t go out of range).
    if (vehiclex <= 1) {
        for (auto& row : maparr) {
            row.insert(row.begin(), ' ');
        }
        width++;
        vehiclex++;
    }

    // Expand right if we are near the right edge.
    if (vehiclex >= width - 2) {
        for (auto& row : maparr) {
            row.push_back(' ');
        }
        width++;
    }

    // Expand top if we are near y <= 1.
    if (vehicley <= 1) {
        maparr.insert(maparr.begin(), std::vector<char>(width, ' '));
        height++;
        vehicley++;
    }

    // Expand bottom if we are near y >= height - 2.
    if (vehicley >= height - 2) {
        maparr.push_back(std::vector<char>(width, ' '));
        height++;
    }
}

void prepareMapForScan() {
    // Expand in all directions twice to provide a safe buffer zone
    for (int i = 0; i < 2; ++i) {
        checkAndExpand();
    }
}

void mapprint() 
{
    if (maparr.empty()) return;

    int rows = maparr.size();
    int cols = maparr[0].size();

    // Print column headers
    cout << "   ";
    for (int x = 0; x < cols; x++) 
    {
        if (x < 10) cout << " " << x << " ";
        else        cout << x << " ";
    }
    cout << "\n";

    // Print each row
    for (int y = 0; y < rows; y++) 
    {
        if (y < 10) cout << " " << y << " ";
        else        cout << y << " ";

        for (int x = 0; x < cols; x++) 
        {
            if (maparr[y][x] == ' ')
            cout << "   ";
            else
            cout << " " << maparr[y][x] << " ";
        }
        cout << "\n";
    }
}

void writeRawMapToFile(const std::string &filename)
{
    std::ofstream outFile(filename);
    if (!outFile)
    {
        std::cerr << "Error: could not open " << filename << " for writing.\n";
        return;
    }

    // Suppose maparr is your 2D vector
    // Just print each row’s characters (with a single space if desired).
    for (int y = 0; y < (int)maparr.size(); ++y)
    {
        for (int x = 0; x < (int)maparr[y].size(); ++x)
        {
            outFile << maparr[y][x];
        }
        outFile << "\n";
    }
    outFile.close();
}