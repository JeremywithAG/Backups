#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>



using namespace std;

// Trim whitespace from both ends of a string
string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\n\r");
    if (first == string::npos) return "";  // Empty string case
    size_t last = str.find_last_not_of(" \t\n\r");
    return str.substr(first, (last - first + 1));
}

// Define a struct to store Employee data
struct Employee {
    int idx;
    string name;
    string email;
    string ic;
    string phoneNum;
    string hireDate;
    string birthDate;
};

// Function to read CSV and extract employee data
vector<Employee> readCSV(const string& filename) {
	
    vector<Employee> employees;
    
    ifstream file(filename);
    
    int counter = 0;  // Initialize counter
    
    if (!file.is_open()) {
        cerr << "Error: Could not open the file!" << endl;
        return employees;
    }

    string line;
    bool isHeader = true;

    while (getline(file, line)) {
        if (isHeader) {  // Skip the first line (header)
            isHeader = false;
            continue;
        }

        stringstream ss(line);
        string cell;
        Employee emp;

        // Read CSV columns
        getline(ss, cell, ','); emp.idx = counter++;
        getline(ss, emp.name, ',');
        getline(ss, emp.email, ',');
        getline(ss, emp.ic, ',');
        getline(ss, emp.phoneNum, ',');
        getline(ss, emp.hireDate, ',');
        getline(ss, emp.birthDate, ',');
        emp.birthDate = trim(emp.birthDate); // Trim trailing spaces

        // Store employee in vector
        employees.push_back(emp);
    }

    file.close();
    return employees;
}

// Function to display employee data
void printEmployees(const vector<Employee>& employees) {
	cout << setw(129) << setfill('=') << "=" << endl; cout << std::setfill(' '); //reset
    cout << left << setw(8) << "Idx"
    	 << setw(11) << "IC"
    	 << setw(36) << "Name"
    	 << setw(16) << "Phone"
    	 << setw(16) << "BirthDate"
    	 << setw(16) << "HiredDate"
    	 << setw(36) << "Email" 
    	 << endl;
    cout << setw(129) << setfill('=') << "=" << endl; cout << std::setfill(' '); //reset
    
    for (const auto& emp : employees) {
        cout << left << setw(8) << emp.idx 
             << left << setw(11) << emp.ic
             << left << setw(36) << emp.name
             << left << setw(16) << emp.phoneNum
             << left << setw(16) << emp.birthDate
             << left << setw(16) << emp.hireDate
             << left << setw(36) << emp.email << endl;
    }
}

int main() {
    string filename = "sample-50-recs.csv";
    vector<Employee> employees = readCSV(filename);

    // Print the extracted data
    printEmployees(employees);

    return 0;
}
